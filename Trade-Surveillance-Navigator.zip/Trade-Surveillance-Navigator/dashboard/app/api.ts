export type LiveCase = {
  id:string; instrument:string; typology:string; risk:number; confidence:number;
  alerts:number; accounts:string; driver:string; color:string; owner:string;
  status:string; age:string; entityLift:number;
};

export type ManagementMetrics = {
  cases:number; highPriority:number; closed:number; averageRisk:number; source:string;
};

export type KafkaStatus = {
  enabled:boolean; mode:string; acceptedTopic:string; completedTopic:string;
  deadLetterTopic:string; published:number; consumed:number; publishFailures:number;
  processingFailures:number; lastPublishedAt:string; lastConsumedAt:string; lastError:string;
};

export type UploadResult = {
  status:string; deliveryMode?:string; eventPublished?:boolean; eventId?:string; fingerprint?:string;
};

const base = process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:8080';
const key = process.env.NEXT_PUBLIC_AEGIS_API_KEY || 'hackathon-local-change-me';
const headers = {'X-Aegis-Key': key};

async function request<T>(path:string, init:RequestInit={}):Promise<T>{
  const response=await fetch(`${base}${path}`,{...init,headers:{...headers,...init.headers},cache:'no-store'});
  if(!response.ok) throw new Error(`${response.status} ${await response.text()}`);
  return response.json() as Promise<T>;
}

export const surveillanceApi = {
  cases:()=>request<LiveCase[]>('/v1/cases'),
  management:()=>request<ManagementMetrics>('/v1/management'),
  kafka:()=>request<KafkaStatus>('/v1/integration/kafka'),
  jobs:()=>request<{jobs:Array<Record<string,unknown>>}>('/v1/ml/file-jobs'),
  upload:async(file:File)=>{
    const body=new FormData(); body.append('file',file);
    return request<UploadResult>('/v1/ingestion/files/trades',{method:'POST',body});
  },
  decide:(caseId:string,disposition:string,reason:string)=>request<Record<string,unknown>>(
    `/v1/cases/${encodeURIComponent(caseId)}/decisions`,{
      method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({investigatorId:'authenticated',role:'INVESTIGATOR',
        disposition:disposition.toUpperCase().replaceAll(' ','_'),reason})
    }),
};
