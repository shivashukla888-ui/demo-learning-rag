# Robustness and control design

Trade Surveillance Navigator is a decision-support system. It prioritises potentially suspicious activity; an authorised investigator remains responsible for the final determination.

## End-to-end golden path

1. Source events enter a separate raw-intake boundary with batch and event idempotency keys.
2. The input layer validates schema, types, mandatory fields and business constraints; rejected rows remain quarantined.
3. Accepted rows are normalised to `trade-event-v1` with immutable source identifiers.
4. Existing surveillance rules identify known patterns.
5. Cohort anomaly, typology features and graph relationships add context.
6. Missing data reduces confidence; it never increases suspicion by default.
7. Related alerts are grouped only when the linkage can be explained.
8. The case summary is generated only from verified evidence identifiers.
9. An investigator reviews the evidence, records rationale and recommends an outcome.
10. Supervisor-controlled dispositions are checked by the workflow API.
11. Every ingestion result, model assessment, evidence view, override and human action is retained in the audit trail.

## Data input controls

| Control | Behaviour |
|---|---|
| Contract | CSV, REST and future streams map to the versioned `trade-event-v1` schema. |
| Isolation | Raw input cannot call scoring or narrative generation directly. |
| Validation | Required fields, ISO-8601 time, BUY/SELL side and positive quantity/price are enforced per record. |
| Deduplication | Batch IDs make retries safe; trade IDs prevent duplicate events from moving forward. |
| Quarantine | Invalid and duplicate records are retained separately from accepted records with explicit reasons. |
| Observability | Received, accepted, rejected, duplicate and completeness measures are emitted for each batch. |

## Model controls

| Control | Behaviour |
|---|---|
| Typology coverage | Wash trading, spoofing, front-running, insider dealing and manipulation have separate required features. |
| Uncertainty | Below 60% required-feature coverage the service returns `INSUFFICIENT_DATA`. |
| Grounding | Below 75% evidence coverage the service warns that a factual narrative must be withheld. |
| Explainability | Every contribution includes direction, points, a business label and evidence references. |
| Human authority | Every assessment returns `HUMAN_REVIEW_REQUIRED`. |
| Monitoring | Precision, recall, calibration, drift, completeness and override rate are tracked by typology. |
| Artifact loading | `MODEL_REQUIRED=true` fails startup when the configured, feature-compatible model artifact is unavailable. |
| Batch isolation | Accepted files are streamed in bounded chunks; score output and completion summaries are written separately from immutable input. |
| Backpressure | File workers, maximum records, entity-state cardinality and minimum free disk are bounded by configuration. |
| Recovery | Atomic progress is emitted per chunk; completed file fingerprints are idempotent and interrupted partitions are safely recomputed. |
| Approval gate | Every trained artifact records its training source, evaluation metrics and `productionApproved` status. Synthetic models remain unapproved. |

The bundled performance values are synthetic validation targets. Production thresholds must be calibrated on temporally separated, approved historical data, assessed for subgroup bias and approved through model governance.

## Workflow controls

- Dispositions require an authenticated actor, role and meaningful rationale.
- Investigators can escalate or request further review.
- Final closure requires the `SUPERVISOR` role.
- Terminal cases reject duplicate decisions.
- The in-memory audit store is suitable for demonstration only; production uses an append-only transactional store with retention and legal-hold controls.

## Failure-mode behaviour

| Failure | Safe behaviour |
|---|---|
| ML service unavailable | Continue rule ingestion, queue scoring retries and display degraded mode. |
| Graph data stale | Exclude graph contribution, reduce confidence and show a data-quality warning. |
| Evidence record missing | Preserve raw evidence, mark the claim unsupported and withhold the generated narrative. |
| Duplicate market event | Idempotency key prevents duplicate alerts, cases and audit events. |
| Feature or score drift | Alert model operations, retain the prior approved version and invoke rollback criteria. |
| LLM timeout or unsafe response | Show structured evidence without a narrative; investigation continues. |

## Production hardening backlog

- Replace demonstration in-memory workflow state with PostgreSQL and an append-only audit ledger.
- Add enterprise identity, least-privilege roles, maker-checker approval and session auditing.
- Introduce a message broker, dead-letter queues, replay controls and exactly-once business keys.
- Encrypt data in transit and at rest; apply field-level masking and jurisdiction-specific retention.
- Add contract, integration, load, resilience, security and model-monitoring tests to the deployment pipeline.
- Validate latency and throughput against representative peak trading volumes before release.
