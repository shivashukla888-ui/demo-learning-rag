from types import SimpleNamespace

from app.llm import OpenAIEvidenceSummarizer
from app.models import EvidenceSummaryRequest


class FakeResponses:
    def __init__(self):
        self.last_request = None

    def create(self, **kwargs):
        self.last_request = kwargs
        return SimpleNamespace(output_text="Potential linked activity requires investigator review [Trade:T183].")


def request():
    return EvidenceSummaryRequest(caseId="WT-102", priority=94,
        riskDrivers=["Seven opposing cycles"], evidenceRefs=["Trade:T183"])


def test_disabled_without_configuration(monkeypatch):
    monkeypatch.setenv("LLM_ENABLED", "false")
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    monkeypatch.delenv("OPENAI_MODEL", raising=False)
    summarizer = OpenAIEvidenceSummarizer()
    assert summarizer.configured is False
    assert summarizer.status()["keyPresent"] is False


def test_summary_uses_responses_api_and_grounding_instructions(monkeypatch):
    monkeypatch.setenv("LLM_ENABLED", "true")
    monkeypatch.setenv("OPENAI_API_KEY", "test-key-not-real")
    monkeypatch.setenv("OPENAI_MODEL", "approved-test-model")
    responses = FakeResponses()
    summarizer = OpenAIEvidenceSummarizer(client=SimpleNamespace(responses=responses))
    summary = summarizer.summarize(request())
    assert "investigator review" in summary
    assert responses.last_request["model"] == "approved-test-model"
    assert "Do not determine misconduct" in responses.last_request["instructions"]
    assert "Trade:T183" in responses.last_request["input"]
