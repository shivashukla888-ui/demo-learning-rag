from datetime import datetime
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator


class ScoreRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    alertId: str = Field(min_length=3, max_length=80)
    asOf: datetime
    typology: Literal["WASH_TRADING", "SPOOFING", "FRONT_RUNNING", "INSIDER_DEALING", "MANIPULATION"] = "WASH_TRADING"
    cohort: str = Field(default="default", min_length=2, max_length=80)
    features: dict[str, float] = Field(default_factory=dict)
    evidenceRefs: list[str] = Field(default_factory=list, max_length=100)

    @field_validator("features")
    @classmethod
    def validate_features(cls, value: dict[str, float]) -> dict[str, float]:
        invalid = [name for name, feature in value.items() if not 0 <= feature <= 1]
        if invalid:
            raise ValueError(f"Feature values must be between 0 and 1: {', '.join(invalid)}")
        return value


class Contribution(BaseModel):
    feature: str
    label: str
    value: float
    points: float
    direction: Literal["increase", "reduce"]
    evidenceRefs: list[str]


class Assessment(BaseModel):
    assessmentId: str
    caseId: str
    typology: str
    risk: int
    confidence: float
    band: Literal["HIGH", "MEDIUM", "LOW", "INSUFFICIENT_DATA"]
    decisionPolicy: Literal["HUMAN_REVIEW_REQUIRED"]
    contributions: list[Contribution]
    evidenceRefs: list[str]
    evidenceCoverage: float
    dataGaps: list[str]
    warnings: list[str]
    versions: dict[str, str]
    mlRisk: int | None = None
    mlProbability: float | None = None
    anomalyScore: float | None = None
    modelMode: Literal["TRAINED_HYBRID", "TRANSPARENT_FALLBACK"] = "TRANSPARENT_FALLBACK"


class BatchScoreItem(BaseModel):
    alertId: str = Field(min_length=3, max_length=80)
    typology: Literal["WASH_TRADING", "SPOOFING", "FRONT_RUNNING", "INSIDER_DEALING", "MANIPULATION"] = "WASH_TRADING"
    features: dict[str, float]
    evidenceRefs: list[str] = Field(default_factory=list, max_length=100)

    @field_validator("features")
    @classmethod
    def validate_batch_features(cls, value: dict[str, float]) -> dict[str, float]:
        invalid = [name for name, feature in value.items() if not 0 <= feature <= 1]
        if invalid:
            raise ValueError(f"Feature values must be between 0 and 1: {', '.join(invalid)}")
        return value


class BatchScoreRequest(BaseModel):
    batchId: str = Field(min_length=3, max_length=100)
    records: list[BatchScoreItem] = Field(min_length=1, max_length=10_000)


class EvidenceSummaryRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    caseId: str = Field(min_length=3, max_length=100)
    typology: str = Field(default="WASH_TRADING", min_length=3, max_length=80)
    priority: int = Field(ge=0, le=100)
    riskDrivers: list[str] = Field(default_factory=list, max_length=30)
    riskReducers: list[str] = Field(default_factory=list, max_length=30)
    timeline: list[str] = Field(default_factory=list, max_length=100)
    entityRelationships: list[str] = Field(default_factory=list, max_length=50)
    evidenceRefs: list[str] = Field(min_length=1, max_length=100)
    dataGaps: list[str] = Field(default_factory=list, max_length=50)


class EvidenceSummaryResponse(BaseModel):
    caseId: str
    summary: str
    evidenceRefs: list[str]
    model: str
    grounded: Literal[True] = True
    decisionPolicy: Literal["HUMAN_REVIEW_REQUIRED"] = "HUMAN_REVIEW_REQUIRED"

