import json
import os
from typing import Any

from .models import EvidenceSummaryRequest


SYSTEM_INSTRUCTIONS = """You are an evidence-grounded trade-surveillance writing assistant.
Summarise only facts present in the supplied structured evidence. Do not determine misconduct,
infer missing ownership, calculate or change the priority score, or recommend autonomous closure.
Use cautious language such as 'potential', 'may', and 'requires investigator review'. Cite supplied
source references inline. If the supplied evidence is insufficient, state that the conclusion is not
supported by the case evidence. Return one concise investigator-readable paragraph."""


class OpenAIEvidenceSummarizer:
    def __init__(self, client: Any | None = None) -> None:
        self.enabled = os.getenv("LLM_ENABLED", "false").strip().lower() in {"1", "true", "yes", "on"}
        self.api_key = os.getenv("OPENAI_API_KEY", "").strip()
        self.model = os.getenv("OPENAI_MODEL", "").strip()
        self._client = client

    @property
    def configured(self) -> bool:
        return self.enabled and bool(self.api_key) and bool(self.model)

    def status(self) -> dict[str, Any]:
        return {
            "enabled": self.enabled,
            "configured": self.configured,
            "provider": "openai" if self.enabled else "disabled",
            "model": self.model if self.configured else None,
            "keyPresent": bool(self.api_key),
            "purpose": "evidence-grounded summary only",
        }

    def _client_instance(self) -> Any:
        if self._client is None:
            from openai import OpenAI

            self._client = OpenAI(api_key=self.api_key)
        return self._client

    def summarize(self, request: EvidenceSummaryRequest) -> str:
        if not self.configured:
            raise RuntimeError("OpenAI evidence summarisation is not configured")

        evidence = request.model_dump()
        response = self._client_instance().responses.create(
            model=self.model,
            instructions=SYSTEM_INSTRUCTIONS,
            input="Create an evidence-grounded case summary from this JSON:\n" + json.dumps(evidence, ensure_ascii=False),
        )
        summary = (response.output_text or "").strip()
        if not summary:
            raise RuntimeError("OpenAI returned an empty evidence summary")
        return summary
