# Trade Surveillance Navigator

Context-aware, multi-typology surveillance and investigation copilot that transforms alerts into explainable, evidence-backed cases while preserving human accountability.

> **AI prioritises. Evidence explains. Human decides.**

## Project structure

- `dashboard/` — runnable interactive investigator workbench
- `backend-java/` — Java 21 / Spring Boot orchestration and investigator API
- `ml-service-python/` — Python / FastAPI scoring and ML service
- `runtime-data/` — local-only intake, model and scoring output (Git ignored)
- `docker-compose.yml` — starts dashboard, Java, Python and PostgreSQL
- `docker-compose.kafka.yml` — optional local Kafka/KRaft event-streaming overlay
- `specs/openapi.yaml` — OpenAPI 3.1 service contract
- `specs/data-model.sql` — audit-oriented reference data model
- `deliverables/AEGIS_solution_blueprint.docx` — PRD, architecture, ML design, governance and delivery plan
- `deliverables/AEGIS_hackathon_pitch.pptx` — executive pitch deck
- `deliverables/AEGIS_implementation_bundle.zip` — portable source bundle

## What is now demonstrable

- **Live scenario lab** — change pattern strength, entity linkage, legitimate market context and evidence completeness; the score and explanation respond immediately.
- **Separate data input layer** — upload CSV data, enforce the canonical schema, quarantine invalid or duplicate rows, preview quality and release validated records only.
- **Recognisable typologies** — wash trading, spoofing/layering and front-running golden paths, plus a contextual low-risk control.
- **Hybrid prioritisation** — rules, behavioural anomaly, graph relationships and risk-reducing context contribute separately.
- **Evidence grounding** — every material claim links to source IDs; below 75% evidence coverage the copilot abstains from generating a factual narrative.
- **Controlled workflow** — rationale and acknowledgement are mandatory; closure requires supervisor authority; all actions create audit events.
- **Management value** — precision, false-positive reduction, case ageing, typology concentration, drift and data-quality indicators.
- **Failure controls** — degraded rule-only operation, retry handling, stale-graph suppression and idempotent event processing are documented in `docs/ROBUSTNESS.md`.

## Runtime architecture

### Production reference architecture

![Trade Surveillance Navigator production architecture](docs/trade-surveillance-production-architecture.png)

The production view includes Kafka broker replication, a schema registry, a dead-letter path, separate evidence stores, human investigation and approval, plus cross-cutting security, observability and governance controls. The Docker setup in this repository implements the same logical event flow in a single-node local form.

### Local runtime flow

```mermaid
flowchart LR
    UI[Dashboard<br/>localhost:3000] -->|API key + CSV| JAVA[Java orchestration API<br/>localhost:8080]
    JAVA -->|validated file| FILES[(Local runtime-data)]
    JAVA -->|accepted-file-v1 event| KAFKA[Kafka KRaft<br/>localhost:9092]
    KAFKA -->|consumer group| JAVA
    JAVA -->|trigger file scan| ML[Python ML service<br/>localhost:8000]
    ML -->|hybrid scores + evidence| JAVA
    JAVA --> DB[(PostgreSQL<br/>cases + audit)]
    KAFKA --> UIK[Kafka UI<br/>localhost:8081]
```

Kafka carries file metadata, fingerprints and workflow events—not the raw CSV content. Input data remains inside the ignored `runtime-data/` boundary. Java uses a SHA-256 file fingerprint as the Kafka key, and Python independently fingerprints completed files so duplicate delivery cannot produce duplicate scoring work.

## Run the dashboard

Requirements: Node.js 22+ and pnpm.

```bash
cd dashboard
pnpm install
pnpm dev
```

Open `http://localhost:3000`.

Production build:

```bash
pnpm build
pnpm start
```

## Run the complete application

Requirements: Docker Desktop. Allocate at least 6 GB of Docker memory for the full Kafka stack.

### Recommended: complete stack with Kafka

```bash
cd /Users/shivamshukla/Documents/HACKTHON
cp .env.example .env
docker compose -f docker-compose.yml -f docker-compose.kafka.yml up -d --build
./scripts/kafka-smoke-test.sh
```

The first build downloads Kafka and application dependencies. Later starts reuse Docker layers and the persistent Kafka volume.

### Lightweight stack without Kafka

```bash
cp .env.example .env
docker compose up -d --build
```

- Java API: `http://localhost:8080`
- Python scoring API and documentation: `http://localhost:8000/docs`
- Dashboard: `http://localhost:3000`
- PostgreSQL: `localhost:5432`

### Kafka components and event contract

The Kafka overlay adds a single-node KRaft broker and Kafka UI while retaining the file watcher as a safe fallback. Validated files publish an `accepted-file-v1` event, Java consumes it and triggers the Python ML scan, and a second event records that the scan was dispatched. Producer idempotence, record-level acknowledgements, three retry attempts and a dead-letter topic are configured.

- Kafka broker for local tools: `localhost:9092`
- Kafka UI: `http://localhost:8081`
- Integration status: `GET http://localhost:8080/v1/integration/kafka`
- Accepted files: `surveillance.file.accepted.v1`
- ML scan triggered: `surveillance.ml.scan.triggered.v1`
- Dead letter: `surveillance.file.accepted.v1.dlt`

| Topic | Producer | Consumer/purpose |
| --- | --- | --- |
| `surveillance.file.accepted.v1` | Java file gateway | Java ML-dispatch consumer group |
| `surveillance.ml.scan.triggered.v1` | Java ML-dispatch consumer | Operational confirmation that Python scanning was invoked |
| `surveillance.file.accepted.v1.dlt` | Kafka retry recovery | Failed events after three retries for operator investigation |

The Kafka-enabled upload sequence is:

1. Dashboard performs immediate client-side CSV checks.
2. Java streams the file to the isolated inbound area.
3. Java validates the filename and required schema, then routes it to accepted or rejected storage.
4. For accepted files, Java calculates a SHA-256 fingerprint and publishes an event with `acks=all` and producer idempotence.
5. The Java consumer reads the event using consumer group `trade-surveillance-navigator-v1` and triggers Python ML scanning.
6. Python processes the CSV in bounded chunks and skips fingerprints already completed.
7. Java synchronises explainable cases to PostgreSQL; human decisions create immutable audit events.

### Inspect Kafka

Open `http://localhost:8081` to inspect brokers, topics, partitions, consumer groups and message payloads. The application status endpoint shows delivery counters and the most recent error:

```bash
curl -H "X-Aegis-Key: ${AEGIS_API_KEY:-hackathon-local-change-me}" \
  http://localhost:8080/v1/integration/kafka
```

List topics from the broker container:

```bash
docker compose -f docker-compose.yml -f docker-compose.kafka.yml \
  exec kafka /opt/kafka/bin/kafka-topics.sh \
  --bootstrap-server localhost:29092 --list
```

Expected healthy status includes `enabled: true`, `mode: KAFKA_EVENT_DRIVEN`, increasing `published` and `consumed` counters, and zero failure counters.

### Reliability and fallback

- Kafka uses KRaft mode and does not require ZooKeeper.
- The local broker has three partitions per surveillance topic and one replica because it is a single-node developer environment.
- Producer idempotence and `acks=all` prevent common duplicate/lost-send scenarios.
- Consumer offsets are acknowledged per successfully handled record.
- Processing failures are retried three times, then routed to the dead-letter topic.
- If Kafka publishing is unavailable, the accepted file remains safely stored and the Python file watcher provides the fallback processing path.
- Kafka data survives container recreation in the named `kafka-data` Docker volume.

### Stop and restart

Stop containers while preserving PostgreSQL and Kafka data:

```bash
docker compose -f docker-compose.yml -f docker-compose.kafka.yml down
```

Restart the Kafka-enabled stack:

```bash
docker compose -f docker-compose.yml -f docker-compose.kafka.yml up -d
```

To return to the non-Kafka stack, stop the overlay and start the base compose file:

```bash
docker compose -f docker-compose.yml -f docker-compose.kafka.yml down
docker compose up -d
```

### Kafka troubleshooting

```bash
# See container health
docker compose -f docker-compose.yml -f docker-compose.kafka.yml ps

# Inspect broker and Java consumer logs
docker compose -f docker-compose.yml -f docker-compose.kafka.yml logs --tail=200 kafka java-api

# Re-run the end-to-end event test
./scripts/kafka-smoke-test.sh
```

If port `9092` or `8081` is already used, stop the conflicting local service or change the host-side port in `docker-compose.kafka.yml`. Do not use `docker compose down -v` unless you intentionally want to delete the local PostgreSQL and Kafka volumes.

### Production boundary

The local single-node broker demonstrates the event contract and operational flow; it is not a production Kafka cluster. Production requires at least three brokers, replication factor three, TLS/SASL, access-control lists, managed secrets, schema compatibility controls, monitoring and alerting, capacity testing, backup/recovery procedures, and a governed deployment platform.

## Use the data input layer

Open **Data input**, download the CSV template, populate it locally and upload it. Input files, trained artifacts and ML outputs stay under the ignored `runtime-data/` boundary and are never committed to Git.

The dashboard validates the file before submission. Java then performs the authoritative validation and file routing, Python scores the accepted file, and PostgreSQL retains cases and human audit events.

### Backend file-drop configuration

The Java backend also provides a configurable file gateway. Edit `backend-java/config/input-files.yml` to add datasets, filename patterns, required columns or change which files are mandatory. Safe defaults remain bundled in `application.yml`. By default it requires trade, order, account and entity CSV files; market data is optional.

Docker stores the files under `runtime-data/input`, separated into `inbound`, `accepted` and `rejected` folders for every dataset. Override the root with `AEGIS_INPUT_ROOT` and the 2 GB limit with `AEGIS_INPUT_MAX_BYTES`. File copies are streamed, so large inputs are not loaded into Java memory.

Upload through the API:

```bash
curl -H "X-Aegis-Key: ${AEGIS_API_KEY}" \
  -F file=@/your/local/path/trades.csv \
  http://localhost:8080/v1/ingestion/files/trades
```

Or copy matching files into `runtime-data/input/inbound/<dataset>/` and call `POST /v1/ingestion/files/scan`. Use `GET /v1/ingestion/files/configuration` to inspect the active contract and `GET /v1/ingestion/files/readiness` to see whether every required dataset is available.

## Demo cases

1. `WT-102` — linked-account round trips (`94 HIGH`).
2. `SP-204` — layered orders and cancellations consistent with a spoofing review scenario (`91 HIGH`).
3. `FR-118` — employee activity preceding client orders (`87 HIGH`).
4. `WT-071` — market context reduces a rule alert to medium priority.
5. `WT-088` — historical behaviour and genuine exposure reduce concern.

Start with **Scenario lab**, change the inputs, and run the assessment. Then open `WT-102` to demonstrate the score journey, claim-to-evidence lineage, graph risk lift, controlled human workflow, model governance and management outcomes.

## Recommended ML architecture

- Calibrated Explainable Boosting Machine for supervised prioritisation.
- Isolation Forest within participant/strategy/liquidity cohorts for behavioural anomaly.
- Min-cost flow for one-to-many fragmented trade matching.
- Exact plus probabilistic entity resolution for beneficial-ownership relationships.
- Constrained agglomerative clustering or HDBSCAN for alert-to-case compression.
- Transparent graph features for common control, synchronisation and circular motifs.

The LLM consumes verified structured evidence only. It does not calculate surveillance metrics, assign the risk score, determine that abuse occurred, or autonomously close cases.

### Optional OpenAI evidence summary

The OpenAI integration is server-side in the Python service and is disabled by default. It uses the Responses API only to convert a verified evidence bundle into an investigator-readable, cited paragraph. Rules and trained ML continue to calculate the surveillance score.

1. Copy the example environment file without committing it:

```bash
cp .env.example .env
```

2. Add a Platform API key and an explicitly approved model to `.env`:

```dotenv
LLM_ENABLED=true
OPENAI_API_KEY=replace-with-your-platform-api-key
OPENAI_MODEL=replace-with-your-approved-model
```

Never put the OpenAI key in `NEXT_PUBLIC_*`, the dashboard source, a Docker image or Git. ChatGPT subscription usage is separate from OpenAI Platform API billing.

3. Rebuild the Python service and verify configuration without exposing the key:

```bash
docker compose up -d --build ml-service
curl http://localhost:8000/v1/llm/status
```

The status response reports only whether a key is present; it never returns the secret. Generate a summary from verified evidence:

```bash
curl -X POST http://localhost:8000/v1/evidence-summary \
  -H 'Content-Type: application/json' \
  -d '{
    "caseId":"WT-102",
    "typology":"WASH_TRADING",
    "priority":94,
    "riskDrivers":["Seven opposing cycles within the review window"],
    "riskReducers":["Moderate volatility context"],
    "timeline":["10:31:04 Account A-104 BUY", "10:31:12 Account A-882 SELL"],
    "entityRelationships":["Ownership:O29 supports common control through UBO-72"],
    "evidenceRefs":["Trade:T183", "Trade:T187", "Ownership:O29", "Position:P905"],
    "dataGaps":["Market-depth evidence incomplete"]
  }'
```

When `LLM_ENABLED=false`, the scoring, file ingestion and human-review workflow continue normally and the summary endpoint returns `503` instead of silently generating unsupported content.

## Trained ML and thousand-record demonstration

The Python service now loads a persisted hybrid artifact containing a calibrated `HistGradientBoostingClassifier` and an `IsolationForest`. On the first Docker startup it trains an 8,000-row deterministic synthetic demonstration artifact under `runtime-data/models`; later restarts reuse that version. Runtime settings are controlled by `MODEL_PATH`, `MODEL_REQUIRED`, `ML_BATCH_SIZE`, `ML_BATCH_WORKERS` and `ML_MODEL_WEIGHT`.

The Python service watches locally accepted trade files every five seconds, extracts surveillance features in streaming 10,000-record chunks and writes scored JSON Lines plus a summary to `runtime-data/ml-output`. Java synchronises the highest-priority results into PostgreSQL-backed cases. Fingerprinted completion records prevent an unchanged file from being scored twice.

### Million-record file provision

Million-record processing uses the file pipeline, not the JSON batch endpoint. The configured path accepts up to 2 million records per file, scores in bounded 10,000-record chunks, retains at most 250,000 entity/instrument state keys, runs at most two files concurrently, reserves 1 GB of output disk and writes atomic progress after every chunk. These controls are configured with `ML_FILE_CHUNK_SIZE`, `ML_MAX_FILE_RECORDS`, `ML_MAX_STATE_KEYS`, `ML_FILE_WORKERS` and `ML_MIN_FREE_DISK_BYTES`.

For better recovery and parallelism, split one million rows into ten 100,000-row files:

```bash
python3 ml-service-python/scripts/generate_trade_file.py \
  --records 1000000 --output /tmp/trades-million.csv

python3 ml-service-python/scripts/partition_trade_file.py \
  /tmp/trades-million.csv --rows-per-part 100000

curl -X POST http://localhost:8080/v1/ingestion/files/scan
```

Progress is available while files are running:

```bash
curl http://localhost:8000/v1/file-jobs
```

Partition completion is restart-safe: completed fingerprints are skipped after restart. A partition interrupted mid-processing is safely recomputed from its beginning; it is not falsely marked complete.

The validated local million-row benchmark completed a 91 MB CSV in 78.3189 seconds at 12,768.31 records/second with one file worker. See `docs/PERFORMANCE.md` for boundaries and qualification.

Generate and submit 5,000 feature records without storing them in Git:

```bash
python3 ml-service-python/scripts/generate_batch_request.py --output /tmp/feature-batch-5000.json
curl -X POST http://localhost:8000/v1/batch-score \
  -H 'Content-Type: application/json' \
  --data @/tmp/feature-batch-5000.json
```

The submission returns a `jobId`. Poll `GET /v1/batch-jobs/{jobId}` for status, measured duration, records per second and results. Requests are processed asynchronously in configurable 1,000-record vectorised chunks, with a maximum of 10,000 records per job.

Train from approved labelled outcomes by supplying a CSV containing `label` plus all feature names:

```bash
docker compose run --rm ml-service sh -c \
  "PYTHONPATH=/app python scripts/train_model.py --training-data /approved/training.csv --output /app/models/surveillance-model.joblib"
```

The bundled artifact proves real training, persistence, loading and inference, but remains marked `productionApproved: false` because its default training data is synthetic. Production approval requires temporally separated validation on governed historical outcomes, bias assessment, model governance sign-off and monitoring thresholds.

All prototype records and metrics are synthetic. They demonstrate the control design and must not be represented as production performance without validation on approved, representative historical data.
