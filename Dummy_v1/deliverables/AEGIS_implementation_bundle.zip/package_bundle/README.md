# AEGIS — Context-Aware Wash Trading Surveillance

Hackathon prototype package for transforming raw rule alerts into explainable, evidence-backed, human-reviewed investigation cases.

## Product boundary

AEGIS prioritises potential wash-trading and coordinated-trading patterns. It does not determine whether market abuse occurred, replace existing surveillance rules, or permit an LLM to calculate core metrics or close cases.

## Architecture

1. **Ingest and normalise:** trades, orders (optional), positions, market data, accounts, clients, traders, ownership and instrument reference data.
2. **Deterministic feature engine:** time delta, one-to-one and one-to-many quantity matching, spread/volatility-normalised price similarity, recurrence, position round trips, participation and economic exposure.
3. **Statistical/ML intelligence:** behavioural anomaly, peer deviation, calibrated prioritisation and related-alert clustering.
4. **Graph intelligence:** common-control resolution, relationship paths, circular motifs and cross-account synchronisation.
5. **Evidence and scoring:** immutable claim/metric/source records, additive score journey, separate risk and confidence, data-quality warnings.
6. **Copilot and workflow:** retrieval-constrained narrative generation, clickable citations, investigator disposition and full audit trail.

## Recommended hybrid ML stack

- **Calibrated Explainable Boosting Machine (EBM)** as the primary supervised ranker when labelled cases are sufficient. EBM learns non-linear feature shapes and selected pairwise interactions while retaining global and local contribution explanations. Calibrate with isotonic regression and evaluate with time-split, entity-grouped validation.
- **Isolation Forest** per participant/liquidity/strategy cohort for cold-start behavioural anomaly. Convert raw anomaly values to cohort percentiles; never present them as probabilities.
- **HDBSCAN or constrained agglomerative clustering** on deterministic similarity plus graph distance for case compression. Require hard cannot-link boundaries across unrelated instruments/time horizons unless instrument equivalence is verified.
- **Probabilistic entity resolution** using deterministic exact matches followed by Fellegi–Sunter-style linkage for fuzzy names/addresses. Preserve match reasons and confidence; do not merge low-confidence records automatically.
- **Graph features**, initially deterministic: common UBO, shortest trusted relationship path, repeated counterparty edge weight, temporal synchronisation, circular motif count. Graph neural networks are out of MVP scope.

The 0–100 score is a calibrated prioritisation score, not a probability of abuse. A transparent feature-weighted fallback is used until representative labels exist.

## Score contract

`risk_score = round(100 × calibrated_rank_probability)` for a validated EBM, or `clip(base_rule + Σ feature_contribution + Σ contextual_reducer, 0, 100)` for the MVP fallback. Contributions are versioned and rendered individually. Unknown inputs contribute zero to risk but reduce confidence; they are never treated as benign.

Confidence combines weighted completeness for trade, market, position, history and ownership data; entity-link confidence; freshness; and out-of-distribution checks. Risk and confidence remain independent.

## Validation gates

- Time-based holdout plus entity-group separation to prevent leakage.
- Metrics: precision@K, recall on seeded typologies, PR-AUC, calibration error, case compression, unsupported-claim rate, citation coverage and investigator preparation time.
- Slice results by asset class, venue, liquidity, volatility, participant type and data-quality tier.
- Champion/challenger comparison against the existing rule queue and transparent weighted baseline.
- Human approval for threshold changes; no automatic retraining from individual dispositions.

## Four-week plan

- **Week 1:** synthetic data, rule simulator, pair/fragment matching, recurrence, position/exposure features and transparent scoring.
- **Week 2:** market normalisation, behavioural/peer baselines, entity graph, alert clustering and scenario validation.
- **Week 3:** evidence store, claim lineage, constrained copilot, confidence/data quality and human workflow.
- **Week 4:** calibration, UI polish, KPI measurement, resilience, governance evidence, rehearsal and judge Q&A.

## Demo sequence

1. Start in the raw-to-case funnel and open WT-102 (obvious high risk).
2. Show every score contribution and the claim → metric → source lineage.
3. Switch to WT-071 to prove market context can reduce priority.
4. Open WT-063 to show 46 → 87 after common-control resolution.
5. Stage an investigator decision and show that confirmation and rationale remain human-controlled.

All metrics and records in the prototype are synthetic and must be labelled accordingly.
