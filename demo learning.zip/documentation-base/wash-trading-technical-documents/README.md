# Wash Trading Technical Documentation

Independent technical-document source used to test code-to-document comparison.

The document represents an older design baseline and intentionally has omissions and outdated
statements. The comparison report should identify them from code evidence; this README does not
describe which statements are incorrect.
