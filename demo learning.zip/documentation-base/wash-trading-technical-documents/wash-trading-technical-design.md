# Wash Trading Surveillance — Technical Design

## Purpose

The component evaluates an incoming trade against recent activity for the same account and raises a
wash-trading surveillance alert when a qualifying opposite-side match is found.

## Component Boundary

`WashTradingSurveillanceService` performs synchronous, in-process evaluation. It owns account-level
trade history and returns an optional alert to its caller. Persistence and downstream alert routing are
outside this component.

## Processing Flow

1. Validate the incoming trade and required domain values.
2. Resolve the account-specific trade history.
3. Remove entries outside the configured event-time window.
4. Compare the incoming trade with retained trades for the same instrument and opposite side.
5. Confirm that price and quantity are sufficiently comparable.
6. Return the first qualifying alert and then retain the incoming trade for later evaluations.

## Matching Rules

A match requires the same account, the same instrument, opposite trade sides, and execution prices
within the configured tolerance. Price variance is calculated against the price of the earlier trade.
The compared quantities must be within ten percent of one another to avoid alerting on immaterial
partial executions.

## Event Identity and Ordering

Trade identifiers are treated as idempotency keys. If the same `tradeId` is received more than once,
the duplicate is ignored and does not participate in a subsequent match. Trades are retained in event
time order, allowing late events to be evaluated consistently.

## Surveillance Window

The window duration is supplied when the service is created. Expired entries are removed immediately
before each evaluation using the incoming trade timestamp. There is no background cleanup scheduler.

## State and Concurrency

Active history is maintained in memory by account ID. A concurrent account map permits independent
accounts to be evaluated concurrently, while access to each account history is synchronized. State is
local to one process and is not shared across service instances.

## Alert Construction

At most one alert is returned for an incoming trade. The alert contains a generated identifier, the
account identifier, alert type `WASH_TRADING_SUSPECT`, the triggering trade timestamp, and a description
identifying both matched trades. Publication or case creation is the caller responsibility.

## Validation and Error Behaviour

Trade ID, account ID, symbol, side, price, and timestamp are mandatory. Price cannot be negative and
quantity must be positive. Invalid domain data or invalid service configuration is rejected with an
exception and is not silently ignored.

## Configuration

The service receives a positive surveillance-window duration and a non-negative price-tolerance value
at construction time. A clock can be supplied to make alert creation deterministic during testing.
