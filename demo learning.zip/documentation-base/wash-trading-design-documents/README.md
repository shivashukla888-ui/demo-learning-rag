# Wash Trading Design Documentation

This is an independent documentation source for the Code-to-Document comparison pipeline.
It intentionally contains the currently approved business description and is indexed separately
from the Java implementation.

Primary document: `wash-trading-business-design.md`
