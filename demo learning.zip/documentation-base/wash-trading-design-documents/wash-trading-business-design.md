# Wash Trading Surveillance Service — Business Design

## Overview

The Wash Trading Surveillance Service detects potential market manipulation where an entity trades
with themselves, or with an affiliated account, to create artificial volume or price movement without
changing actual market-risk exposure.

## Core Rules

### Time Window

The service evaluates trades occurring within a rolling five-minute window (300,000 milliseconds).

### Side Matching

The service triggers when an account executes both a BUY and a SELL, in either order, in the same asset.

### Price Tolerance

The service triggers when the execution prices of the two opposite orders are within 1% (0.01) of each other.

### State Management

The service keeps an in-memory chronological array of active trades for each account ID. Records outside
the configured time window are purged before surveillance evaluation.
