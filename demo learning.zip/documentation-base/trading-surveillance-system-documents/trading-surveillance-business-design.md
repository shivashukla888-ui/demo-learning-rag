# Trading Surveillance System — Business and Technical Design

## Purpose

The Trading Surveillance System receives trade activity, validates and filters each trade, applies
applicable market-abuse detectors, and distributes generated alerts to configured subscribers.

## Inbound Processing

Apache Camel consumes messages from the ActiveMQ `TRADE_INPUT` queue. A batch splitter converts an
inbound batch into individual trades before validation and detection. Invalid trades are handled and
sent to the `TRADE_DEAD_LETTER` queue.

## Validation and Filtering

The validation chain checks mandatory trade fields, positive price and quantity, and whether the asset
type is supported. Valid trades with a notional value below the configured minimum are filtered before
detection. Filtered trades are not treated as invalid events.

## Detection Coordination

The detection engine evaluates every detector whose `supports` method accepts the trade. To prevent
duplicate cases for a single event, processing stops after the first detector creates an alert, so each
trade produces at most one alert.

## Surveillance Rules

### Wash Trading

The detector identifies direct self-trading when trader and counterparty identifiers are equal. The
rule applies only to asset types enabled for wash-trade detection.

### Spoofing

Spoofing detection evaluates large, unexecuted crypto orders within the configured time window. State
is partitioned by trader and symbol so activity in different instruments cannot be combined toward the
minimum count.

### Flash Crash

Flash-crash detection applies to configured asset types and executed trades. It compares the current
price with the highest observed price for the symbol within the configured window and alerts when the
percentage decline reaches the configured threshold.

### Momentum Ignition

Momentum ignition applies to executed trades and groups activity by trader and symbol. It requires the
configured minimum count, a consistent trade direction, and non-decreasing prices within the window.

## Detector State and Concurrency

Rolling detector histories are held in process memory. History collections are synchronized so multiple
Camel consumer threads can safely evaluate trades for the same trader or symbol. Detector state is not
shared between application instances and is rebuilt after restart.

## Alert Construction and Severity

Alerts record the triggering trade ID, trade time, alert creation time, type, message, and severity.
Severity is resolved from configuration for wash trade, spoofing, flash crash, and momentum ignition
alert types; unknown types use the configured default severity.

## Alert Distribution

The dispatcher notifies each registered subscriber, including console, log-file, and email subscribers.
A failure in one subscriber is isolated, recorded, and does not prevent the remaining subscribers from
receiving the alert. Delivery retries and durable alert persistence are outside this application.

## Configuration

Asset coverage, time windows, thresholds, minimum trade value, severity mappings, and email recipients
are loaded from YAML configuration. Runtime configuration changes require an application restart.
