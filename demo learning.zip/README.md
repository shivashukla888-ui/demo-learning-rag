# Banking Surveillance RAG

A Spring Boot application for investigating banking-surveillance material using two isolated Retrieval-Augmented Generation (RAG) sources.

## Knowledge sources

- **Policy PDF RAG**: `src/main/resources/knowledge/pdf/banking-surveillance.pdf`
- **Codebase RAG**: `knowledge-base/trading-surveillance-system`

The sources are indexed into separate PGVector tables. A question asked in PDF mode can never use the codebase store, and a question asked in Codebase mode can never use the PDF store.

## Project structure

```text
banking-surveillance-rag/
├── src/main/java/com/bankingsurveillance/rag/
│   ├── api/          REST endpoints for the browser UI
│   ├── config/       PGVector configuration
│   ├── ingestion/    PDF and codebase indexing
│   └── BankingSurveillanceRagApplication.java
├── src/main/resources/
│   ├── knowledge/pdf/  Banking-surveillance PDFs
│   └── static/         Browser interface
├── knowledge-base/     Source code indexed by Codebase RAG
├── compose.yaml        PostgreSQL + PGVector database
└── pom.xml             Java 21 Maven configuration
```

## Run in IntelliJ

1. Ensure Docker Desktop is running.
2. In the Application run configuration, set `OPENAI_API_KEY` as an environment variable.
3. Run `BankingSurveillanceRagApplication`.
4. Open `http://localhost:8080`.

On the first run the application creates its vector tables and indexes both sources. Future starts preserve the indexed data and skip duplicate ingestion.

## API

- `GET /api/ask?mode=pdf&question=...`
- `GET /api/ask?mode=code&question=...`
- `GET /api/status`
- `GET /api/source-pdf`
