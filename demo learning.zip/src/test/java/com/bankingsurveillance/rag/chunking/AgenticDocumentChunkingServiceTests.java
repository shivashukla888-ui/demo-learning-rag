package com.bankingsurveillance.rag.chunking;

import com.bankingsurveillance.rag.analysis.service.IntelligenceModelClient;
import com.bankingsurveillance.rag.analysis.service.PromptTemplateService;
import com.bankingsurveillance.rag.chunking.model.AgenticChunkGroup;
import com.bankingsurveillance.rag.chunking.model.AgenticChunkPlan;
import org.junit.jupiter.api.Test;
import org.springframework.ai.document.Document;

import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;

class AgenticDocumentChunkingServiceTests {

    @Test
    void appliesValidatedAgentPlanWithoutRewritingDocumentText() {
        IntelligenceModelClient model = new IntelligenceModelClient() {
            @Override public <T> T generate(String prompt, Class<T> responseType) {
                return responseType.cast(new AgenticChunkPlan(List.of(
                        new AgenticChunkGroup("Rules", "BUSINESS_RULE", List.of(0)),
                        new AgenticChunkGroup("Storage", "STORAGE", List.of(1)))));
            }
            @Override public String generateText(String prompt) { return ""; }
        };
        PromptTemplateService prompts = new PromptTemplateService(null) {
            @Override public String render(String name, Map<String, String> values) {
                return values.get("sections");
            }
        };
        AgenticDocumentChunkingService service = new AgenticDocumentChunkingService(model, prompts, true);
        Document source = new Document("# Rules\nOpposite sides match.\n\n# Storage\nState is in memory.",
                Map.of("source", "design.md", "source_type", "technical_design"));

        List<Document> chunks = service.chunk(source);

        assertThat(chunks).hasSize(2);
        assertThat(chunks).extracting(Document::getContent)
                .containsExactly("# Rules\nOpposite sides match.", "# Storage\nState is in memory.");
        assertThat(chunks).extracting(document -> document.getMetadata().get("requirement_type"))
                .containsExactly("BUSINESS_RULE", "STORAGE");
        assertThat(chunks).allSatisfy(document ->
                assertThat(document.getMetadata()).containsEntry("chunk_strategy", "agentic_structural"));
    }
}
