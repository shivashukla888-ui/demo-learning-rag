package com.bankingsurveillance.rag.chunking;

import org.junit.jupiter.api.Test;
import org.springframework.ai.document.Document;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

class JavaAstChunkingServiceTests {
    private final JavaAstChunkingService service = new JavaAstChunkingService();

    @Test
    void createsTypeAndMethodChunksWithSourceMetadata() {
        String source = """
                package com.bank;
                public class Detector {
                    private int threshold = 10;
                    public boolean evaluate(int value) {
                        return value > threshold;
                    }
                }
                """;

        List<Document> chunks = service.chunk("com/bank/Detector.java", source);

        assertThat(chunks).extracting(document -> document.getMetadata().get("chunk_type"))
                .contains("TYPE", "METHOD");
        Document method = chunks.stream()
                .filter(document -> "METHOD".equals(document.getMetadata().get("chunk_type")))
                .findFirst().orElseThrow();
        assertThat(method.getContent()).contains("boolean evaluate", "value > threshold");
        assertThat(method.getMetadata()).containsEntry("class", "Detector")
                .containsEntry("source", "com/bank/Detector.java")
                .containsEntry("chunk_strategy", "java_ast");
        assertThat((Number) method.getMetadata().get("start_line")).isNotNull();
    }
}
