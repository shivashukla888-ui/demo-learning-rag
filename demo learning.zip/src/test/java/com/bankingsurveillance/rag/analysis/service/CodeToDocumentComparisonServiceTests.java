package com.bankingsurveillance.rag.analysis.service;

import com.bankingsurveillance.rag.analysis.model.CodeEvidence;
import com.bankingsurveillance.rag.analysis.model.CodeKnowledgeItem;
import com.bankingsurveillance.rag.analysis.model.CodeKnowledgeModel;
import com.bankingsurveillance.rag.analysis.model.ComparisonFinding;
import com.bankingsurveillance.rag.analysis.model.ComparisonResult;
import com.bankingsurveillance.rag.analysis.model.DifferenceType;
import com.bankingsurveillance.rag.analysis.model.Severity;
import com.bankingsurveillance.rag.analysis.model.StructuredDifferenceReport;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.ai.document.Document;
import org.springframework.ai.vectorstore.SearchRequest;
import org.springframework.ai.vectorstore.VectorStore;

import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyMap;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class CodeToDocumentComparisonServiceTests {

    @Test
    void stopsBeforeModelCallWhenCodeWasNotRetrieved() {
        VectorStore documentation = mock(VectorStore.class);
        VectorStore code = mock(VectorStore.class);
        IntelligenceModelClient model = mock(IntelligenceModelClient.class);
        when(code.similaritySearch(any(SearchRequest.class))).thenReturn(List.of());
        CodeToDocumentComparisonService service = service(documentation, code, model, mock(PromptTemplateService.class));

        assertThatThrownBy(() -> service.compare("trade validation"))
                .isInstanceOf(IllegalStateException.class).hasMessageContaining("code repository");
        verify(model, never()).generate(any(), eq(CodeKnowledgeModel.class));
    }

    @Test
    void retrievesSourcesThenProducesStructuredAndMarkdownReports() {
        VectorStore documentation = mock(VectorStore.class);
        VectorStore code = mock(VectorStore.class);
        IntelligenceModelClient model = mock(IntelligenceModelClient.class);
        PromptTemplateService prompts = mock(PromptTemplateService.class);
        when(documentation.similaritySearch(any(SearchRequest.class)))
                .thenReturn(List.of(new Document("Documented validation", Map.of("source", "design.pdf"))));
        when(code.similaritySearch(any(SearchRequest.class)))
                .thenReturn(List.of(new Document("if (amount <= 0) throw error", Map.of("source", "AmountValidator.java"))));
        when(prompts.render(eq("code-knowledge-extraction.txt"), anyMap())).thenReturn("extract");
        when(prompts.render(eq("document-comparison.txt"), anyMap())).thenReturn("compare");
        when(prompts.render(eq("updated-document.txt"), anyMap())).thenReturn("update");
        CodeEvidence evidence = new CodeEvidence("AmountValidator.java", "validate", "Rejects non-positive amounts");
        CodeKnowledgeModel knowledge = new CodeKnowledgeModel(List.of(
                new CodeKnowledgeItem("VALIDATION", "Trade validation", "Amount must be positive", List.of(evidence))));
        ComparisonFinding finding = new ComparisonFinding(DifferenceType.INCONSISTENT_RULE, Severity.HIGH,
                "VALIDATION", "Trade validation", "Amount must be positive", List.of(evidence),
                "Document permits zero", "Code rejects zero", "State that amount must be greater than zero");
        ComparisonFinding aligned = new ComparisonFinding(DifferenceType.CORRECT, Severity.LOW,
                "VALIDATION", "Trade validation", "Amount must be positive", List.of(evidence),
                "Document says amount must be positive", "No difference", "No change required");
        when(model.generate("extract", CodeKnowledgeModel.class)).thenReturn(knowledge);
        when(model.generate("compare", StructuredDifferenceReport.class))
                .thenReturn(new StructuredDifferenceReport("ignored", List.of(aligned, finding)));
        when(model.generateText("update")).thenReturn("# Updated Trade Validation");

        ComparisonResult result = service(documentation, code, model, prompts).compare("trade validation");

        assertThat(result.structuredReport().feature()).isEqualTo("trade validation");
        assertThat(result.structuredReport().findings()).containsExactly(finding);
        assertThat(result.markdownReport()).contains("INCONSISTENT_RULE", "Code rejects zero");
        assertThat(result.updatedDocumentContent()).isEqualTo("# Updated Trade Validation");
        verify(documentation).similaritySearch(any(SearchRequest.class));
        verify(code).similaritySearch(any(SearchRequest.class));
    }

    private CodeToDocumentComparisonService service(VectorStore documentation, VectorStore code,
                                                     IntelligenceModelClient model, PromptTemplateService prompts) {
        return new CodeToDocumentComparisonService(documentation, code, model, prompts,
                new MarkdownDifferenceReportRenderer(), new ObjectMapper(), 8, 12);
    }
}
