package com.bankingsurveillance.rag.analysis.service;

import com.bankingsurveillance.rag.analysis.model.CodeEvidence;
import com.bankingsurveillance.rag.analysis.model.ComparisonFinding;
import com.bankingsurveillance.rag.analysis.model.DifferenceType;
import com.bankingsurveillance.rag.analysis.model.Severity;
import com.bankingsurveillance.rag.analysis.model.StructuredDifferenceReport;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

class MarkdownDifferenceReportRendererTests {
    private final MarkdownDifferenceReportRenderer renderer = new MarkdownDifferenceReportRenderer();

    @Test
    void rendersFindingAndEvidence() {
        ComparisonFinding finding = new ComparisonFinding(DifferenceType.MISSING_IN_DOCUMENT,
                Severity.HIGH, "VALIDATION", "Trade validation", "Amount must be positive",
                List.of(new CodeEvidence("AmountValidator.java", "validate", "Rejects non-positive amounts")),
                "No matching documentation found", "Validation is undocumented",
                "Add the positive-amount validation rule");

        String markdown = renderer.render(new StructuredDifferenceReport("trade validation", List.of(finding)));

        assertThat(markdown).contains("Trade validation", "MISSING_IN_DOCUMENT", "AmountValidator.java",
                "Add the positive-amount validation rule");
    }
}
