package com.bankingsurveillance.rag.assessment;

import com.bankingsurveillance.rag.analysis.model.*;
import com.bankingsurveillance.rag.analysis.service.DocumentationAssessmentService;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

class DocumentationAssessmentServiceTests {
    private final DocumentationAssessmentService service = new DocumentationAssessmentService();

    @Test
    void fullyAlignedCompleteInventoryProducesOneHundred() {
        AssessmentResult result = service.assess(findings(10, DifferenceType.CORRECT, Severity.LOW), 10);

        assertThat(result.assessmentComplete()).isTrue();
        assertThat(result.overallScore()).isEqualTo(100);
        assertThat(result.accuracy()).isEqualTo(100);
        assertThat(result.coverage()).isEqualTo(100);
        assertThat(result.status()).isEqualTo(AssessmentStatus.ALIGNED);
    }

    @Test
    void twoMatchesDoNotProduceConfidentOneHundredWhenInventoryIsLarger() {
        AssessmentResult result = service.assess(findings(2, DifferenceType.CORRECT, Severity.LOW), 10);

        assertThat(result.assessmentComplete()).isFalse();
        assertThat(result.overallScore()).isNull();
        assertThat(result.status()).isEqualTo(AssessmentStatus.ASSESSMENT_INCOMPLETE);
        assertThat(result.coverage()).isEqualTo(20);
        assertThat(result.unresolvedBehaviors()).isEqualTo(8);
    }

    @Test
    void undocumentedImplementationBehaviorReducesCoverageAndBaseScore() {
        List<ComparisonFinding> findings = new ArrayList<>();
        findings.addAll(findings(7, DifferenceType.CORRECT, Severity.LOW));
        findings.addAll(findings(3, DifferenceType.MISSING_IN_DOCUMENT, Severity.LOW));

        AssessmentResult result = service.assess(findings, 10);

        assertThat(result.assessmentComplete()).isTrue();
        assertThat(result.overallScore()).isEqualTo(70);
        assertThat(result.accuracy()).isEqualTo(100);
        assertThat(result.coverage()).isEqualTo(70);
        assertThat(result.summary().missingCount()).isEqualTo(3);
    }

    @Test
    void partialDocumentationReceivesHalfWeight() {
        List<ComparisonFinding> findings = new ArrayList<>();
        findings.addAll(findings(6, DifferenceType.CORRECT, Severity.LOW));
        findings.addAll(findings(4, DifferenceType.CONDITIONAL, Severity.LOW));

        AssessmentResult result = service.assess(findings, 10);

        assertThat(result.overallScore()).isEqualTo(80);
        assertThat(result.accuracy()).isEqualTo(80);
        assertThat(result.coverage()).isEqualTo(100);
    }

    @Test
    void misalignmentUsesImplementationBehaviorDenominator() {
        List<ComparisonFinding> findings = new ArrayList<>();
        findings.addAll(findings(7, DifferenceType.CORRECT, Severity.LOW));
        findings.addAll(findings(2, DifferenceType.CONDITIONAL, Severity.LOW));
        findings.addAll(findings(1, DifferenceType.INCORRECT, Severity.LOW));

        AssessmentResult result = service.assess(findings, 10);

        assertThat(result.overallScore()).isEqualTo(80);
        assertThat(result.summary().incorrectCount()).isEqualTo(1);
    }

    @Test
    void criticalContradictionPreventsAlignedApprovalState() {
        List<ComparisonFinding> findings = new ArrayList<>();
        findings.addAll(findings(9, DifferenceType.CORRECT, Severity.LOW));
        findings.add(finding(99, DifferenceType.INCORRECT, Severity.CRITICAL));

        AssessmentResult result = service.assess(findings, 10);

        assertThat(result.assessmentComplete()).isTrue();
        assertThat(result.status()).isEqualTo(AssessmentStatus.NEEDS_REVIEW);
        assertThat(result.overallScore()).isLessThan(90);
    }

    @Test
    void emptyEvidenceProducesIncompleteAssessmentWithoutScore() {
        AssessmentResult result = service.assess(List.of(), 0);

        assertThat(result.assessmentComplete()).isFalse();
        assertThat(result.overallScore()).isNull();
        assertThat(result.status()).isEqualTo(AssessmentStatus.ASSESSMENT_INCOMPLETE);
        assertThat(result.evidenceConfidence()).isZero();
    }

    @Test
    void dimensionsWithoutEvidenceAreNotScoredAsZero() {
        AssessmentResult result = service.assess(findings(5, DifferenceType.CORRECT, Severity.LOW), 5);

        assertThat(result.dimensionScores().businessLogicAlignment()).isEqualTo(100);
        assertThat(result.dimensionScores().technicalAccuracy()).isNull();
        assertThat(result.dimensionScores().operationalAccuracy()).isNull();
    }

    @Test
    void technicalEvidenceProducesATechnicalScore() {
        ComparisonFinding technical = new ComparisonFinding(DifferenceType.INCORRECT, Severity.HIGH,
                AssessmentDimension.TECHNICAL_ACCURACY, "STATE", "State management", "State is process-local",
                List.of(new CodeEvidence("Service.java", "evaluate", "Uses an in-memory map")),
                "State is shared in a database", "Document contradicts implementation", "Document process-local state");

        AssessmentResult result = service.assess(List.of(technical), 1);

        assertThat(result.dimensionScores().technicalAccuracy()).isZero();
        assertThat(result.dimensionScores().operationalAccuracy()).isNull();
    }

    @Test
    void statusThresholdsRemainDeterministic() {
        assertThat(service.statusFor(90)).isEqualTo(AssessmentStatus.ALIGNED);
        assertThat(service.statusFor(89)).isEqualTo(AssessmentStatus.MOSTLY_ALIGNED);
        assertThat(service.statusFor(75)).isEqualTo(AssessmentStatus.MOSTLY_ALIGNED);
        assertThat(service.statusFor(74)).isEqualTo(AssessmentStatus.NEEDS_REVIEW);
        assertThat(service.statusFor(60)).isEqualTo(AssessmentStatus.NEEDS_REVIEW);
        assertThat(service.statusFor(59)).isEqualTo(AssessmentStatus.MATERIALLY_MISALIGNED);
    }

    private List<ComparisonFinding> findings(int count, DifferenceType type, Severity severity) {
        List<ComparisonFinding> findings = new ArrayList<>();
        for (int index = 0; index < count; index++) findings.add(finding(index, type, severity));
        return findings;
    }

    private ComparisonFinding finding(int index, DifferenceType type, Severity severity) {
        String documentEvidence = type == DifferenceType.MISSING_IN_DOCUMENT
                ? "No matching documentation found" : "Document statement " + index;
        return new ComparisonFinding(type, severity, AssessmentDimension.BUSINESS_LOGIC_ALIGNMENT,
                "TEST", "Capability " + index, "Behavior " + index,
                List.of(new CodeEvidence("Test" + index + ".java", "method" + index, "Evidence " + index)),
                documentEvidence, "Difference " + index, "Recommended change " + index);
    }
}
