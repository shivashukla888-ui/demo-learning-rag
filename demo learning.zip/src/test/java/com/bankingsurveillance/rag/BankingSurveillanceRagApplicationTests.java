package com.bankingsurveillance.rag;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankingSurveillanceRagApplicationTests {

	@Test
	void contextLoads() {
	}

}
