package com.bankingsurveillance.rag.documentation;

import com.bankingsurveillance.rag.chunking.AgenticDocumentChunkingService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ai.document.Document;
import org.springframework.ai.vectorstore.VectorStore;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;

@Component
public class TradingSurveillanceDocumentIngestionService implements CommandLineRunner {
    private static final Logger log = LoggerFactory.getLogger(TradingSurveillanceDocumentIngestionService.class);
    private static final String TABLE_NAME = "trading_surveillance_document_store_v1";
    private final VectorStore vectorStore;
    private final JdbcTemplate jdbcTemplate;
    private final AgenticDocumentChunkingService chunkingService;

    @Value("${rag.trading-surveillance-document-path:documentation-base/trading-surveillance-system-documents/trading-surveillance-business-design.md}")
    private String documentPath;

    public TradingSurveillanceDocumentIngestionService(
            @Qualifier("tradingSurveillanceDocumentVectorStore") VectorStore vectorStore,
            JdbcTemplate jdbcTemplate, AgenticDocumentChunkingService chunkingService) {
        this.vectorStore = vectorStore;
        this.jdbcTemplate = jdbcTemplate;
        this.chunkingService = chunkingService;
    }

    @Override
    public void run(String... args) throws IOException {
        if (hasDocuments()) {
            log.info("Trading Surveillance System design document is already indexed; skipping ingestion.");
            return;
        }
        Path path = Path.of(documentPath);
        if (!Files.isRegularFile(path))
            throw new IllegalStateException("Trading Surveillance design document was not found: " + path.toAbsolutePath());
        Document document = new Document(Files.readString(path), Map.of(
                "source", path.getFileName().toString(),
                "source_type", "business_design",
                "repository", "trading-surveillance-system"));
        List<Document> chunks = chunkingService.chunk(document);
        vectorStore.accept(chunks);
        log.info("Trading Surveillance System design document indexed: {} chunks.", chunks.size());
    }

    private boolean hasDocuments() {
        Long count = jdbcTemplate.queryForObject("select count(*) from " + TABLE_NAME, Long.class);
        return count != null && count > 0;
    }
}
