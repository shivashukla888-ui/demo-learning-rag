package com.bankingsurveillance.rag.documentation;

import com.bankingsurveillance.rag.chunking.AgenticDocumentChunkingService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ai.document.Document;
import org.springframework.ai.vectorstore.VectorStore;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Component
public class DesignDocumentIngestionService implements CommandLineRunner {
    private static final Logger log = LoggerFactory.getLogger(DesignDocumentIngestionService.class);
    private static final String TABLE_NAME = "wash_trading_document_store_v2";

    private final VectorStore vectorStore;
    private final JdbcTemplate jdbcTemplate;
    private final AgenticDocumentChunkingService chunkingService;

    @Value("${rag.design-document-path:documentation-base}")
    private String documentPath;

    public DesignDocumentIngestionService(
            @Qualifier("designDocumentVectorStore") VectorStore vectorStore,
            JdbcTemplate jdbcTemplate, AgenticDocumentChunkingService chunkingService) {
        this.vectorStore = vectorStore;
        this.jdbcTemplate = jdbcTemplate;
        this.chunkingService = chunkingService;
    }

    @Override
    public void run(String... args) throws IOException {
        if (hasDocuments()) {
            log.info("Wash-trading design documents are already indexed; skipping duplicate ingestion.");
            return;
        }
        Path root = Path.of(documentPath);
        if (!Files.isDirectory(root))
            throw new IllegalStateException("Design-document directory was not found: " + root.toAbsolutePath());

        List<Document> documents = new ArrayList<>();
        try (var paths = Files.walk(root)) {
            paths.filter(Files::isRegularFile).filter(this::isSupported)
                    .forEach(path -> documents.add(readDocument(root, path)));
        }
        List<Document> chunks = documents.stream().flatMap(document -> chunkingService.chunk(document).stream()).toList();
        if (chunks.isEmpty()) throw new IllegalStateException("No readable design-document content was found");
        vectorStore.accept(chunks);
        log.info("Wash-trading design documentation indexed: {} files, {} chunks.",
                documents.size(), chunks.size());
    }

    private boolean hasDocuments() {
        Long count = jdbcTemplate.queryForObject("select count(*) from " + TABLE_NAME, Long.class);
        return count != null && count > 0;
    }

    private boolean isSupported(Path path) {
        String name = path.getFileName().toString().toLowerCase();
        return !name.equals("readme.md") && !path.toString().contains("trading-surveillance-system-documents")
                && (name.endsWith(".md") || name.endsWith(".txt"));
    }

    private Document readDocument(Path root, Path path) {
        try {
            String source = root.relativize(path).toString();
            String sourceType = source.contains("technical-documents")
                    ? "technical_design" : "business_design";
            return new Document(Files.readString(path),
                    Map.of("source", source, "source_type", sourceType));
        } catch (IOException exception) {
            throw new IllegalStateException("Could not read design document " + path, exception);
        }
    }
}
