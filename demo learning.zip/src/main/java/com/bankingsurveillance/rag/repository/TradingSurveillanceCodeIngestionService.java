package com.bankingsurveillance.rag.repository;

import com.bankingsurveillance.rag.chunking.JavaAstChunkingService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ai.document.Document;
import org.springframework.ai.transformer.splitter.TokenTextSplitter;
import org.springframework.ai.vectorstore.VectorStore;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.LinkedHashMap;
import java.util.Map;

@Component
public class TradingSurveillanceCodeIngestionService implements CommandLineRunner {
    private static final Logger log = LoggerFactory.getLogger(TradingSurveillanceCodeIngestionService.class);
    private static final String TABLE_NAME = "trading_surveillance_code_store_v2";
    private final VectorStore vectorStore;
    private final JdbcTemplate jdbcTemplate;
    private final JavaAstChunkingService javaAstChunkingService;

    @Value("${rag.trading-surveillance-codebase-path:knowledge-base/trading-surveillance-system}")
    private String codebasePath;

    public TradingSurveillanceCodeIngestionService(
            @Qualifier("tradingSurveillanceCodeVectorStore") VectorStore vectorStore,
            JdbcTemplate jdbcTemplate, JavaAstChunkingService javaAstChunkingService) {
        this.vectorStore = vectorStore;
        this.jdbcTemplate = jdbcTemplate;
        this.javaAstChunkingService = javaAstChunkingService;
    }

    @Override
    public void run(String... args) throws IOException {
        if (hasDocuments()) {
            log.info("Trading Surveillance System repository is already indexed; skipping ingestion.");
            return;
        }
        Path root = Path.of(codebasePath);
        if (!Files.isDirectory(root))
            throw new IllegalStateException("Trading Surveillance System directory was not found: " + root.toAbsolutePath());
        List<Document> sources = new ArrayList<>();
        try (var paths = Files.walk(root)) {
            paths.filter(Files::isRegularFile).filter(this::isSourceFile)
                    .forEach(path -> sources.addAll(readSources(root, path)));
        }
        List<Document> chunks = new TokenTextSplitter().apply(sources);
        if (chunks.isEmpty()) throw new IllegalStateException("No readable source files were found in " + root);
        vectorStore.accept(chunks);
        log.info("Trading Surveillance System repository indexed: {} files, {} chunks.", sources.size(), chunks.size());
    }

    private boolean hasDocuments() {
        Long count = jdbcTemplate.queryForObject("select count(*) from " + TABLE_NAME, Long.class);
        return count != null && count > 0;
    }

    private boolean isSourceFile(Path path) {
        String name = path.getFileName().toString().toLowerCase();
        return name.endsWith(".java") || name.endsWith(".md") || name.endsWith(".yml")
                || name.endsWith(".yaml") || name.endsWith(".xml");
    }

    private List<Document> readSources(Path root, Path path) {
        try {
            String sourcePath = root.relativize(path).toString();
            String content = Files.readString(path);
            if (sourcePath.toLowerCase().endsWith(".java")) {
                List<Document> astChunks = javaAstChunkingService.chunk(sourcePath, content);
                if (!astChunks.isEmpty()) return astChunks.stream().map(document -> {
                    Map<String, Object> metadata = new LinkedHashMap<>(document.getMetadata());
                    metadata.put("repository", "trading-surveillance-system");
                    return new Document(document.getContent(), metadata);
                }).toList();
            }
            return List.of(new Document("File: " + sourcePath + "\n\n" + content,
                    Map.of("source", sourcePath, "source_type", "code",
                            "repository", "trading-surveillance-system",
                            "chunk_strategy", "token_fallback")));
        } catch (IOException exception) {
            throw new IllegalStateException("Could not read source file " + path, exception);
        }
    }

}
