package com.bankingsurveillance.rag.chunking;

import com.bankingsurveillance.rag.analysis.service.IntelligenceModelClient;
import com.bankingsurveillance.rag.analysis.service.PromptTemplateService;
import com.bankingsurveillance.rag.chunking.model.AgenticChunkGroup;
import com.bankingsurveillance.rag.chunking.model.AgenticChunkPlan;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ai.document.Document;
import org.springframework.ai.transformer.splitter.TokenTextSplitter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Component
public class AgenticDocumentChunkingService {
    private static final Logger log = LoggerFactory.getLogger(AgenticDocumentChunkingService.class);
    private static final Pattern MARKDOWN_HEADING = Pattern.compile("(?m)^(#{1,6})\s+(.+?)\s*$");
    private final IntelligenceModelClient modelClient;
    private final PromptTemplateService prompts;
    private final boolean enabled;

    public AgenticDocumentChunkingService(IntelligenceModelClient modelClient, PromptTemplateService prompts,
            @Value("${rag.chunking.agentic.enabled:true}") boolean enabled) {
        this.modelClient = modelClient;
        this.prompts = prompts;
        this.enabled = enabled;
    }

    public List<Document> chunk(Document source) {
        List<Section> sections = sections(source.getContent());
        if (!enabled || sections.size() < 2) return fallback(source);
        try {
            AgenticChunkPlan plan = modelClient.generate(prompts.render("agentic-document-chunking.txt",
                    Map.of("source", String.valueOf(source.getMetadata().getOrDefault("source", "document")),
                            "sections", serialize(sections))), AgenticChunkPlan.class);
            return materialize(source, sections, plan);
        } catch (RuntimeException exception) {
            log.warn("Agentic chunk planning failed for {}; using structural/token fallback: {}",
                    source.getMetadata().getOrDefault("source", "document"), exception.getMessage());
            return fallback(source);
        }
    }

    private List<Document> materialize(Document source, List<Section> sections, AgenticChunkPlan plan) {
        if (plan == null || plan.groups().isEmpty()) return fallback(source);
        Set<Integer> used = new HashSet<>();
        List<Document> chunks = new ArrayList<>();
        for (AgenticChunkGroup group : plan.groups()) {
            List<Integer> indexes = group.sectionIndexes().stream().distinct().sorted().toList();
            if (indexes.isEmpty() || indexes.stream().anyMatch(index -> index < 0 || index >= sections.size()))
                return fallback(source);
            if (indexes.stream().anyMatch(used::contains)) return fallback(source);
            indexes.forEach(used::add);
            String content = indexes.stream().map(sections::get).map(Section::content)
                    .reduce((left, right) -> left + "\n\n" + right).orElse("");
            chunks.addAll(splitIfNecessary(document(source, content, group.title(), group.chunkType(), indexes)));
        }
        if (used.size() != sections.size()) return fallback(source);
        return chunks;
    }

    private Document document(Document source, String content, String title, String chunkType,
                              List<Integer> indexes) {
        Map<String, Object> metadata = new LinkedHashMap<>(source.getMetadata());
        metadata.put("chunk_strategy", "agentic_structural");
        metadata.put("section_title", title == null ? "" : title);
        metadata.put("requirement_type", chunkType == null ? "GENERAL" : chunkType);
        metadata.put("section_indexes", indexes.toString());
        return new Document(content, metadata);
    }

    private List<Document> splitIfNecessary(Document document) {
        return new TokenTextSplitter().apply(List.of(document));
    }

    private List<Document> fallback(Document source) {
        Map<String, Object> metadata = new LinkedHashMap<>(source.getMetadata());
        metadata.put("chunk_strategy", "structural_token_fallback");
        return new TokenTextSplitter().apply(List.of(new Document(source.getContent(), metadata)));
    }

    private List<Section> sections(String content) {
        Matcher matcher = MARKDOWN_HEADING.matcher(content);
        List<Integer> starts = new ArrayList<>();
        List<String> titles = new ArrayList<>();
        while (matcher.find()) { starts.add(matcher.start()); titles.add(matcher.group(2).trim()); }
        if (starts.isEmpty()) return paragraphSections(content);
        List<Section> result = new ArrayList<>();
        if (starts.getFirst() > 0 && !content.substring(0, starts.getFirst()).isBlank())
            result.add(new Section("Preamble", content.substring(0, starts.getFirst()).trim()));
        for (int index = 0; index < starts.size(); index++) {
            int end = index + 1 < starts.size() ? starts.get(index + 1) : content.length();
            result.add(new Section(titles.get(index), content.substring(starts.get(index), end).trim()));
        }
        return result;
    }

    private List<Section> paragraphSections(String content) {
        String[] paragraphs = content.split("\\R\\s*\\R");
        List<Section> result = new ArrayList<>();
        for (int index = 0; index < paragraphs.length; index++)
            if (!paragraphs[index].isBlank()) result.add(new Section("Section " + index, paragraphs[index].trim()));
        return result;
    }

    private String serialize(List<Section> sections) {
        StringBuilder result = new StringBuilder();
        for (int index = 0; index < sections.size(); index++)
            result.append("[SECTION ").append(index).append("] ").append(sections.get(index).title())
                    .append('\n').append(sections.get(index).content()).append("\n\n");
        return result.toString();
    }

    private record Section(String title, String content) { }
}
