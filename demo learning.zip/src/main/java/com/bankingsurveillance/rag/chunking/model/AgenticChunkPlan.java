package com.bankingsurveillance.rag.chunking.model;

import java.util.List;

public record AgenticChunkPlan(List<AgenticChunkGroup> groups) {
    public AgenticChunkPlan {
        groups = groups == null ? List.of() : List.copyOf(groups);
    }
}
