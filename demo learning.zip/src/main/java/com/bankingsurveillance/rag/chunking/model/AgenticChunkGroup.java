package com.bankingsurveillance.rag.chunking.model;

import java.util.List;

public record AgenticChunkGroup(String title, String chunkType, List<Integer> sectionIndexes) {
    public AgenticChunkGroup {
        sectionIndexes = sectionIndexes == null ? List.of() : List.copyOf(sectionIndexes);
    }
}
