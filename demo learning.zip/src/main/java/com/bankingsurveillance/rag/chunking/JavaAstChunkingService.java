package com.bankingsurveillance.rag.chunking;

import com.sun.source.tree.ClassTree;
import com.sun.source.tree.CompilationUnitTree;
import com.sun.source.tree.MethodTree;
import com.sun.source.tree.Tree;
import com.sun.source.tree.VariableTree;
import com.sun.source.util.JavacTask;
import com.sun.source.util.SourcePositions;
import com.sun.source.util.TreePathScanner;
import com.sun.source.util.Trees;
import org.springframework.ai.document.Document;
import org.springframework.stereotype.Component;

import javax.tools.JavaCompiler;
import javax.tools.SimpleJavaFileObject;
import javax.tools.ToolProvider;
import java.net.URI;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Component
public class JavaAstChunkingService {

    public List<Document> chunk(String sourcePath, String source) {
        JavaCompiler compiler = ToolProvider.getSystemJavaCompiler();
        if (compiler == null) return List.of();
        try {
            SourceFile sourceFile = new SourceFile(sourcePath, source);
            JavacTask task = (JavacTask) compiler.getTask(null, null, null,
                    List.of("-proc:none"), null, List.of(sourceFile));
            CompilationUnitTree unit = task.parse().iterator().next();
            SourcePositions positions = Trees.instance(task).getSourcePositions();
            String packageName = unit.getPackageName() == null ? "" : unit.getPackageName().toString();
            List<Document> chunks = new ArrayList<>();
            new TreePathScanner<Void, String>() {
                @Override
                public Void visitClass(ClassTree classTree, String parentType) {
                    String className = classTree.getSimpleName().toString();
                    if (className.isBlank()) return super.visitClass(classTree, parentType);
                    String qualifiedType = parentType == null || parentType.isBlank()
                            ? className : parentType + "." + className;
                    addTypeOverview(unit, positions, sourcePath, source, packageName,
                            qualifiedType, classTree, chunks);
                    for (Tree member : classTree.getMembers()) {
                        if (member instanceof MethodTree method)
                            addMethod(unit, positions, sourcePath, source, packageName,
                                    qualifiedType, method, chunks);
                    }
                    return super.visitClass(classTree, qualifiedType);
                }
            }.scan(unit, "");
            return chunks;
        } catch (RuntimeException | java.io.IOException exception) {
            return List.of();
        }
    }

    private void addTypeOverview(CompilationUnitTree unit, SourcePositions positions, String sourcePath,
                                 String source, String packageName, String typeName, ClassTree type,
                                 List<Document> chunks) {
        StringBuilder content = new StringBuilder();
        if (!packageName.isBlank()) content.append("package ").append(packageName).append(";\n\n");
        content.append(type.getKind()).append(' ').append(typeName).append("\n");
        type.getMembers().stream().filter(member -> member instanceof VariableTree)
                .forEach(member -> content.append(member).append('\n'));
        chunks.add(document(content.toString(), sourcePath, packageName, typeName, "", "TYPE",
                line(unit, positions.getStartPosition(unit, type))));
    }

    private void addMethod(CompilationUnitTree unit, SourcePositions positions, String sourcePath,
                           String source, String packageName, String typeName, MethodTree method,
                           List<Document> chunks) {
        long start = positions.getStartPosition(unit, method);
        long end = positions.getEndPosition(unit, method);
        if (start < 0 || end <= start || end > source.length()) return;
        String methodName = method.getName().contentEquals("<init>") ? typeName : method.getName().toString();
        String signature = methodName + method.getParameters();
        String content = source.substring((int) start, (int) end);
        chunks.add(document(content, sourcePath, packageName, typeName, signature,
                method.getName().contentEquals("<init>") ? "CONSTRUCTOR" : "METHOD",
                line(unit, start)));
    }

    private Document document(String content, String sourcePath, String packageName, String typeName,
                              String symbol, String chunkType, long startLine) {
        Map<String, Object> metadata = new LinkedHashMap<>();
        metadata.put("source", sourcePath);
        metadata.put("source_type", "code");
        metadata.put("language", "java");
        metadata.put("chunk_strategy", "java_ast");
        metadata.put("chunk_type", chunkType);
        metadata.put("package", packageName);
        metadata.put("class", typeName);
        metadata.put("symbol", symbol);
        metadata.put("start_line", startLine);
        return new Document(content, metadata);
    }

    private long line(CompilationUnitTree unit, long position) {
        return position < 0 ? 1 : unit.getLineMap().getLineNumber(position);
    }

    private static final class SourceFile extends SimpleJavaFileObject {
        private final String source;
        private SourceFile(String path, String source) {
            super(URI.create("string:///" + path.replace('\\', '/').replace(" ", "%20")), Kind.SOURCE);
            this.source = source;
        }
        @Override public CharSequence getCharContent(boolean ignoreEncodingErrors) { return source; }
    }
}
