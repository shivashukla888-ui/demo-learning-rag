package com.bankingsurveillance.rag.api;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.document.Document;
import org.springframework.ai.vectorstore.SearchRequest;
import org.springframework.ai.vectorstore.VectorStore;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
public class RagQueryController {
    private final ChatClient chatClient;
    private final VectorStore pdfVectorStore;
    private final VectorStore washTradingCodeStore;
    private final VectorStore tradingSurveillanceCodeStore;
    private final JdbcTemplate jdbcTemplate;

    @Value("classpath:/knowledge/pdf/banking-surveillance.pdf")
    private Resource sourcePdf;

    public RagQueryController(ChatClient.Builder builder,
                              @Qualifier("pdfVectorStore") VectorStore pdfVectorStore,
                              @Qualifier("codeVectorStore") VectorStore washTradingCodeStore,
                              @Qualifier("tradingSurveillanceCodeVectorStore") VectorStore tradingSurveillanceCodeStore,
                              JdbcTemplate jdbcTemplate) {
        this.chatClient = builder.build();
        this.pdfVectorStore = pdfVectorStore;
        this.washTradingCodeStore = washTradingCodeStore;
        this.tradingSurveillanceCodeStore = tradingSurveillanceCodeStore;
        this.jdbcTemplate = jdbcTemplate;
    }

    @GetMapping("/api/ask")
    public Map<String, String> ask(@RequestParam String question,
                                   @RequestParam(defaultValue = "code") String mode,
                                   @RequestParam(defaultValue = "wash-trading-surveillance") String repository) {
        boolean codeMode = "code".equals(mode);
        VectorStore selectedStore = codeMode ? selectCodeStore(repository) : pdfVectorStore;
        String sourceLabel = codeMode ? repositoryLabel(repository) : "banking-surveillance PDF";
        List<Document> matches = selectedStore.similaritySearch(SearchRequest.query(question).withTopK(5));
        if (matches == null || matches.isEmpty())
            return Map.of("answer", "No relevant " + sourceLabel + " chunks were found. Check indexing first.");
        String context = matches.stream().map(Document::getContent).collect(Collectors.joining("\n\n---\n\n"));
        String prompt = "Answer only from the supplied " + sourceLabel + " context. "
                + "If the answer is not in the context, say that clearly.\n\nQuestion: " + question
                + "\n\nContext:\n" + context;
        return Map.of("answer", chatClient.prompt().user(prompt).call().content());
    }

    @GetMapping("/api/status")
    public Map<String, Object> status() {
        return Map.of("pdfChunks", count("banking_pdf_store"),
                "codeChunks", count("wash_trading_code_store"),
                "washTradingCodeChunks", count("wash_trading_code_store"),
                "tradingSurveillanceCodeChunks", count("trading_surveillance_code_store_v2"));
    }

    @GetMapping(value = "/api/source-pdf", produces = MediaType.APPLICATION_PDF_VALUE)
    public ResponseEntity<Resource> sourcePdf() {
        return ResponseEntity.ok().contentType(MediaType.APPLICATION_PDF).body(sourcePdf);
    }

    private VectorStore selectCodeStore(String repository) {
        return switch (repository) {
            case "wash-trading-surveillance" -> washTradingCodeStore;
            case "trading-surveillance-system" -> tradingSurveillanceCodeStore;
            default -> throw new IllegalArgumentException("Unsupported code repository: " + repository);
        };
    }

    private String repositoryLabel(String repository) {
        return switch (repository) {
            case "wash-trading-surveillance" -> "Wash Trading Surveillance repository";
            case "trading-surveillance-system" -> "Trading Surveillance System repository";
            default -> repository;
        };
    }

    private long count(String tableName) {
        Long count = jdbcTemplate.queryForObject("select count(*) from " + tableName, Long.class);
        return count == null ? 0 : count;
    }
}
