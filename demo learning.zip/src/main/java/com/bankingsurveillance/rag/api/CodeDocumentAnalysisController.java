package com.bankingsurveillance.rag.api;

import com.bankingsurveillance.rag.analysis.model.ComparisonRequest;
import com.bankingsurveillance.rag.analysis.model.ComparisonResult;
import com.bankingsurveillance.rag.analysis.service.CodeToDocumentComparisonService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/analysis")
public class CodeDocumentAnalysisController {
    private final CodeToDocumentComparisonService comparisonService;

    public CodeDocumentAnalysisController(CodeToDocumentComparisonService comparisonService) {
        this.comparisonService = comparisonService;
    }

    @PostMapping("/compare")
    public ComparisonResult compare(@RequestBody(required = false) ComparisonRequest request) {
        return request == null
                ? comparisonService.compare(null)
                : comparisonService.compare(request.feature(), request.repository(), request.documentSource());
    }

    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<Map<String, String>> invalidRequest(IllegalArgumentException exception) {
        return ResponseEntity.badRequest().body(Map.of("error", exception.getMessage()));
    }

    @ExceptionHandler(IllegalStateException.class)
    public ResponseEntity<Map<String, String>> invalidState(IllegalStateException exception) {
        return ResponseEntity.badRequest().body(Map.of("error", exception.getMessage()));
    }
}
