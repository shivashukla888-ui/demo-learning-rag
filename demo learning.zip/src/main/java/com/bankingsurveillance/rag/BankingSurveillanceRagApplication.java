package com.bankingsurveillance.rag;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BankingSurveillanceRagApplication {

	public static void main(String[] args) {
		SpringApplication.run(BankingSurveillanceRagApplication.class, args);
	}

}
