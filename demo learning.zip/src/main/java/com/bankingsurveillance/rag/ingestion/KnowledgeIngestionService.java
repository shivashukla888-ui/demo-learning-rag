package com.bankingsurveillance.rag.ingestion;

import com.bankingsurveillance.rag.chunking.JavaAstChunkingService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ai.document.Document;
import org.springframework.ai.reader.pdf.PagePdfDocumentReader;
import org.springframework.ai.transformer.splitter.TextSplitter;
import org.springframework.ai.transformer.splitter.TokenTextSplitter;
import org.springframework.ai.vectorstore.VectorStore;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.io.Resource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Component
public class KnowledgeIngestionService implements CommandLineRunner {

    private static final Logger log = LoggerFactory.getLogger(KnowledgeIngestionService.class);
    private final VectorStore pdfVectorStore;
    private final VectorStore codeVectorStore;
    private final JdbcTemplate jdbcTemplate;
    private final JavaAstChunkingService javaAstChunkingService;

    @Value("classpath:/knowledge/pdf/banking-surveillance.pdf")
    private Resource surveillancePdf;

    @Value("${rag.codebase-path:knowledge-base/wash-trading-surveillance}")
    private String codebasePath;

    public KnowledgeIngestionService(@Qualifier("pdfVectorStore") VectorStore pdfVectorStore,
                            @Qualifier("codeVectorStore") VectorStore codeVectorStore,
                            JdbcTemplate jdbcTemplate,
                            JavaAstChunkingService javaAstChunkingService) {
        this.pdfVectorStore = pdfVectorStore;
        this.codeVectorStore = codeVectorStore;
        this.jdbcTemplate = jdbcTemplate;
        this.javaAstChunkingService = javaAstChunkingService;
    }

    @Override
    public void run(String... args) throws Exception {
        ingestPdf();
        ingestCodebase();
    }

    private void ingestPdf() {
        if (hasDocuments("banking_pdf_store")) {
            log.info("Banking-surveillance PDF is already indexed; skipping duplicate ingestion.");
            return;
        }
        TextSplitter splitter = new TokenTextSplitter();
        List<Document> pages = new PagePdfDocumentReader(surveillancePdf).get();
        List<Document> chunks = splitter.apply(pages);
        if (chunks.isEmpty()) {
            throw new IllegalStateException("No readable text was extracted from banking-surveillance.pdf");
        }
        pdfVectorStore.accept(chunks);
        log.info("Banking-surveillance PDF indexed successfully: {} pages, {} chunks.", pages.size(), chunks.size());
    }

    private void ingestCodebase() throws IOException {
        if (hasDocuments("wash_trading_code_store")) {
            log.info("Trading Surveillance System codebase is already indexed; skipping duplicate ingestion.");
            return;
        }
        Path root = Path.of(codebasePath);
        if (!Files.isDirectory(root)) {
            throw new IllegalStateException("Codebase directory was not found: " + root.toAbsolutePath());
        }
        List<Document> sources = new ArrayList<>();
        try (var paths = Files.walk(root)) {
            paths.filter(Files::isRegularFile).filter(this::isSourceFile)
                    .forEach(path -> sources.addAll(toDocuments(root, path)));
        }
        codeVectorStore.accept(new TokenTextSplitter().apply(sources));
        log.info("Trading Surveillance System codebase indexed: {} source files.", sources.size());
    }

    private boolean hasDocuments(String tableName) {
        Long count = jdbcTemplate.queryForObject("select count(*) from " + tableName, Long.class);
        return count != null && count > 0;
    }

    private boolean isSourceFile(Path path) {
        String name = path.getFileName().toString().toLowerCase();
        return name.endsWith(".java") || name.endsWith(".md") || name.endsWith(".yml")
                || name.endsWith(".yaml") || name.endsWith(".xml");
    }

    private List<Document> toDocuments(Path root, Path path) {
        try {
            String relativePath = root.relativize(path).toString();
            String content = Files.readString(path);
            if (relativePath.toLowerCase().endsWith(".java")) {
                List<Document> astChunks = javaAstChunkingService.chunk(relativePath, content);
                if (!astChunks.isEmpty()) return astChunks;
            }
            return List.of(new Document("File: " + relativePath + "\n\n" + content,
                    Map.of("source", relativePath, "source_type", "code",
                            "chunk_strategy", "token_fallback")));
        } catch (IOException exception) {
            throw new IllegalStateException("Could not read source file " + path, exception);
        }
    }
}
