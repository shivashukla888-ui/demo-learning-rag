package com.bankingsurveillance.rag.analysis.model;

import java.util.List;

public record StructuredDifferenceReport(String feature, List<ComparisonFinding> findings) {
    public StructuredDifferenceReport {
        findings = findings == null ? List.of() : List.copyOf(findings);
    }
}
