package com.bankingsurveillance.rag.analysis.model;

import java.util.List;

public record ComparisonFinding(DifferenceType type, Severity severity,
                                AssessmentDimension assessmentDimension, String category,
                                String businessCapability, String businessRule,
                                List<CodeEvidence> codeEvidence, String documentEvidence,
                                String difference, String recommendedChange) {
    public ComparisonFinding {
        codeEvidence = codeEvidence == null ? List.of() : List.copyOf(codeEvidence);
    }

    public ComparisonFinding(DifferenceType type, Severity severity, String category,
                             String businessCapability, String businessRule,
                             List<CodeEvidence> codeEvidence, String documentEvidence,
                             String difference, String recommendedChange) {
        this(type, severity, null, category, businessCapability, businessRule,
                codeEvidence, documentEvidence, difference, recommendedChange);
    }
}
