package com.bankingsurveillance.rag.analysis.model;
public enum AssessmentStatus {
    ALIGNED,
    MOSTLY_ALIGNED,
    NEEDS_REVIEW,
    MATERIALLY_MISALIGNED,
    ASSESSMENT_INCOMPLETE
}
