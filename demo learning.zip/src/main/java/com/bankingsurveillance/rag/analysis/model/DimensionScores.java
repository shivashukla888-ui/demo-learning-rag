package com.bankingsurveillance.rag.analysis.model;
public record DimensionScores(Integer businessLogicAlignment, Integer documentationCompleteness,
                              Integer technicalAccuracy, Integer operationalAccuracy) { }
