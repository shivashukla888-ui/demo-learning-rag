package com.bankingsurveillance.rag.analysis.service;

import com.bankingsurveillance.rag.analysis.model.CodeEvidence;
import com.bankingsurveillance.rag.analysis.model.ComparisonFinding;
import com.bankingsurveillance.rag.analysis.model.StructuredDifferenceReport;
import org.springframework.stereotype.Component;

@Component
public class MarkdownDifferenceReportRenderer {
    public String render(StructuredDifferenceReport report) {
        StringBuilder output = new StringBuilder("# Code-to-Document Difference Report\n\n")
                .append("**Feature:** ").append(safe(report.feature())).append("\n\n")
                .append("**Findings:** ").append(report.findings().size()).append("\n\n");
        int number = 1;
        for (ComparisonFinding finding : report.findings()) {
            output.append("## ").append(number++).append(". ").append(safe(finding.businessCapability())).append("\n\n")
                    .append("- **Type:** ").append(finding.type()).append("\n")
                    .append("- **Severity:** ").append(finding.severity()).append("\n")
                    .append("- **Category:** ").append(safe(finding.category())).append("\n")
                    .append("- **Business rule:** ").append(safe(finding.businessRule())).append("\n")
                    .append("- **Document evidence:** ").append(safe(finding.documentEvidence())).append("\n")
                    .append("- **Difference:** ").append(safe(finding.difference())).append("\n")
                    .append("- **Recommended change:** ").append(safe(finding.recommendedChange())).append("\n")
                    .append("- **Code evidence:**\n");
            if (finding.codeEvidence().isEmpty()) output.append("  - None\n");
            for (CodeEvidence evidence : finding.codeEvidence()) {
                output.append("  - `").append(safe(evidence.source())).append("`");
                if (evidence.symbol() != null && !evidence.symbol().isBlank())
                    output.append(" — `").append(evidence.symbol()).append("`");
                output.append(": ").append(safe(evidence.behavior())).append("\n");
            }
            output.append('\n');
        }
        return output.toString();
    }

    private String safe(String value) {
        return value == null || value.isBlank() ? "Not available" : value;
    }
}
