package com.bankingsurveillance.rag.analysis.service;

import com.bankingsurveillance.rag.analysis.model.*;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.ai.document.Document;
import org.springframework.ai.vectorstore.SearchRequest;
import org.springframework.ai.vectorstore.VectorStore;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class CodeToDocumentComparisonService {
    private final VectorStore designDocumentationStore;
    private final VectorStore pdfDocumentationStore;
    private final VectorStore tradingSurveillanceDocumentationStore;
    private final VectorStore washTradingCodeStore;
    private final VectorStore tradingSurveillanceCodeStore;
    private final IntelligenceModelClient modelClient;
    private final PromptTemplateService prompts;
    private final MarkdownDifferenceReportRenderer markdownRenderer;
    private final DocumentationAssessmentService assessmentService;
    private final ObjectMapper objectMapper;
    private final int documentTopK;
    private final int codeTopK;

    @Autowired
    public CodeToDocumentComparisonService(
            @Qualifier("designDocumentVectorStore") VectorStore designDocumentationStore,
            @Qualifier("pdfVectorStore") VectorStore pdfDocumentationStore,
            @Qualifier("tradingSurveillanceDocumentVectorStore") VectorStore tradingSurveillanceDocumentationStore,
            @Qualifier("codeVectorStore") VectorStore washTradingCodeStore,
            @Qualifier("tradingSurveillanceCodeVectorStore") VectorStore tradingSurveillanceCodeStore,
            IntelligenceModelClient modelClient, PromptTemplateService prompts,
            MarkdownDifferenceReportRenderer markdownRenderer,
            DocumentationAssessmentService assessmentService, ObjectMapper objectMapper,
            @Value("${rag.analysis.document-top-k:8}") int documentTopK,
            @Value("${rag.analysis.code-top-k:24}") int codeTopK) {
        this.designDocumentationStore = designDocumentationStore;
        this.pdfDocumentationStore = pdfDocumentationStore;
        this.tradingSurveillanceDocumentationStore = tradingSurveillanceDocumentationStore;
        this.washTradingCodeStore = washTradingCodeStore;
        this.tradingSurveillanceCodeStore = tradingSurveillanceCodeStore;
        this.modelClient = modelClient;
        this.prompts = prompts;
        this.markdownRenderer = markdownRenderer;
        this.assessmentService = assessmentService;
        this.objectMapper = objectMapper;
        this.documentTopK = documentTopK;
        this.codeTopK = codeTopK;
    }

    CodeToDocumentComparisonService(VectorStore documentationStore, VectorStore codeStore,
                                    IntelligenceModelClient modelClient, PromptTemplateService prompts,
                                    MarkdownDifferenceReportRenderer markdownRenderer, ObjectMapper objectMapper,
                                    int documentTopK, int codeTopK) {
        this(documentationStore, documentationStore, documentationStore, codeStore, codeStore, modelClient, prompts,
                markdownRenderer, new DocumentationAssessmentService(), objectMapper, documentTopK, codeTopK);
    }

    public ComparisonResult compare(String requestedFeature) {
        return compare(requestedFeature, "wash-trading-surveillance", "design-documents");
    }

    public ComparisonResult compare(String requestedFeature, String repository, String documentSource) {
        String feature = requestedFeature == null || requestedFeature.isBlank()
                ? "banking surveillance business and technical behavior" : requestedFeature.trim();
        VectorStore selectedDocumentationStore = selectDocumentationStore(documentSource);
        VectorStore selectedCodeStore = selectCodeStore(repository);
        List<Document> codeChunks = search(selectedCodeStore,
                feature + "\nTechnical verification coverage: validation, detector applicability, alert multiplicity, "
                        + "state partitioning, concurrency, severity mapping, subscriber failure behavior, "
                        + "timestamps, duplicate-event handling, and price or quantity calculations.", codeTopK);
        requireResults(codeChunks, "code repository");

        CodeKnowledgeModel knowledge = modelClient.generate(prompts.render("code-knowledge-extraction.txt",
                Map.of("feature", feature, "code_context", join(codeChunks))), CodeKnowledgeModel.class);
        if (knowledge.items().isEmpty())
            throw new IllegalStateException("No meaningful business or technical behavior was extracted from code");
        CodeKnowledgeModel inventory = normalizedInventory(knowledge);
        int implementationBehaviorCount = inventory.items().size();
        List<Document> documentChunks = searchDocumentation(selectedDocumentationStore, feature, inventory);
        requireResults(documentChunks, "documentation");
        String documentContext = join(documentChunks);
        List<ComparisonFinding> findings = compareInventory(feature, inventory, documentContext);
        StructuredDifferenceReport report = new StructuredDifferenceReport(feature, findings);
        AssessmentResult assessment = assessmentService.assess(report.findings(), implementationBehaviorCount);
        String markdown = markdownRenderer.render(report);
        String updatedDocument = modelClient.generateText(prompts.render("updated-document.txt",
                Map.of("feature", feature, "document_context", documentContext,
                        "difference_report", toJson(report))));
        return new ComparisonResult(report, assessment, markdown, updatedDocument);
    }

    private CodeKnowledgeModel normalizedInventory(CodeKnowledgeModel knowledge) {
        Map<String, CodeKnowledgeItem> unique = new LinkedHashMap<>();
        for (CodeKnowledgeItem item : knowledge.items()) {
            String key = normalize(item.category()) + "|" + normalize(item.businessCapability())
                    + "|" + normalize(item.behavior());
            unique.putIfAbsent(key, item);
        }
        return new CodeKnowledgeModel(List.copyOf(unique.values()));
    }

    private List<ComparisonFinding> compareInventory(String feature, CodeKnowledgeModel inventory,
                                                     String documentContext) {
        List<ComparisonFinding> findings = new ArrayList<>();
        for (CodeKnowledgeItem item : inventory.items()) {
            CodeKnowledgeModel singleBehavior = new CodeKnowledgeModel(List.of(item));
            StructuredDifferenceReport generated = modelClient.generate(prompts.render("document-comparison.txt",
                    Map.of("feature", feature, "code_knowledge", toJson(singleBehavior),
                            "document_context", documentContext)), StructuredDifferenceReport.class);
            if (generated.findings().isEmpty()) findings.add(unresolvedFinding(item));
            else findings.add(selectMaterialFinding(generated.findings()));
        }
        return findings;
    }

    private ComparisonFinding selectMaterialFinding(List<ComparisonFinding> candidates) {
        return candidates.stream().max((left, right) -> {
            int typeComparison = Integer.compare(materiality(left.type()), materiality(right.type()));
            if (typeComparison != 0) return typeComparison;
            return Integer.compare(severityRank(left.severity()), severityRank(right.severity()));
        }).orElseThrow();
    }

    private int materiality(DifferenceType type) {
        if (type == null) return 4;
        return switch (type) {
            case INCORRECT, INCONSISTENT_RULE -> 6;
            case OUTDATED_DOCUMENTATION, IMPLEMENTATION_CHANGED -> 5;
            case MISSING_IN_DOCUMENT, TECHNICAL_DETAIL_MISSING, DOCUMENT_ONLY -> 4;
            case REQUIRES_REVIEW -> 3;
            case CONDITIONAL -> 2;
            case MATCHED, CORRECT -> 1;
        };
    }

    private int severityRank(Severity severity) {
        if (severity == null) return 0;
        return switch (severity) {
            case CRITICAL -> 4;
            case HIGH -> 3;
            case MEDIUM -> 2;
            case LOW -> 1;
        };
    }

    private ComparisonFinding unresolvedFinding(CodeKnowledgeItem item) {
        return new ComparisonFinding(DifferenceType.REQUIRES_REVIEW, Severity.MEDIUM,
                AssessmentDimension.DOCUMENTATION_COMPLETENESS, item.category(),
                item.businessCapability(), item.behavior(), item.evidence(),
                "No conclusive documentation comparison was produced",
                "The implementation behavior could not be classified against the retrieved document evidence.",
                "Review this behavior manually and add or correct the corresponding documentation.");
    }

    private String normalize(String value) {
        return value == null ? "" : value.trim().toLowerCase(java.util.Locale.ROOT);
    }

    private VectorStore selectCodeStore(String repository) {
        String selected = repository == null || repository.isBlank()
                ? "wash-trading-surveillance" : repository.trim();
        return switch (selected) {
            case "wash-trading-surveillance" -> washTradingCodeStore;
            case "trading-surveillance-system" -> tradingSurveillanceCodeStore;
            default -> throw new IllegalArgumentException("Unsupported code repository: " + selected);
        };
    }

    private VectorStore selectDocumentationStore(String source) {
        String selected = source == null || source.isBlank() ? "design-documents" : source.trim();
        return switch (selected) {
            case "design-documents" -> designDocumentationStore;
            case "banking-surveillance-pdf" -> pdfDocumentationStore;
            case "trading-design-documents" -> tradingSurveillanceDocumentationStore;
            default -> throw new IllegalArgumentException("Unsupported documentation source: " + selected);
        };
    }

    private List<Document> searchDocumentation(VectorStore store, String feature, CodeKnowledgeModel inventory) {
        String inventoryJson = abbreviate(toJson(inventory), 6_000);
        List<Document> general = search(store,
                feature + "\nImplemented behavior inventory:\n" + inventoryJson, documentTopK);
        List<Document> technical = search(store,
                feature + " technical design architecture components APIs storage state concurrency integrations "
                        + "runtime sequencing validation error handling\nImplemented behavior inventory:\n" + inventoryJson,
                documentTopK);
        Map<String, Document> unique = new LinkedHashMap<>();
        general.forEach(document -> unique.put(documentKey(document), document));
        technical.forEach(document -> unique.putIfAbsent(documentKey(document), document));
        return List.copyOf(unique.values());
    }

    private String documentKey(Document document) {
        return document.getMetadata().getOrDefault("source", "unknown") + "|" + document.getContent();
    }

    private List<Document> search(VectorStore store, String query, int topK) {
        List<Document> results = store.similaritySearch(SearchRequest.query(query).withTopK(topK));
        return results == null ? List.of() : results;
    }

    private void requireResults(List<Document> results, String source) {
        if (results.isEmpty())
            throw new IllegalStateException("No relevant " + source + " chunks were found; check indexing first");
    }

    private String join(List<Document> documents) {
        return documents.stream().map(document -> "SOURCE: "
                + document.getMetadata().getOrDefault("source", "unknown") + "\n" + document.getContent())
                .collect(Collectors.joining("\n\n---\n\n"));
    }

    private String abbreviate(String value, int maximumLength) {
        return value.length() <= maximumLength ? value : value.substring(0, maximumLength);
    }

    private String toJson(Object value) {
        try {
            return objectMapper.writeValueAsString(value);
        } catch (JsonProcessingException exception) {
            throw new IllegalStateException("Could not serialize analysis data", exception);
        }
    }
}
