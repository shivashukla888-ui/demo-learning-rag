package com.bankingsurveillance.rag.analysis.service;

import com.bankingsurveillance.rag.analysis.model.*;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Locale;

@Service
public class DocumentationAssessmentService {
    static final int MINIMUM_COMPLETE_BEHAVIORS = 5;

    public AssessmentResult assess(List<ComparisonFinding> findings) {
        List<ComparisonFinding> safeFindings = safe(findings);
        return assess(safeFindings, implementationFindingCount(safeFindings));
    }

    public AssessmentResult assess(List<ComparisonFinding> findings, int discoveredImplementationBehaviors) {
        List<ComparisonFinding> safeFindings = safe(findings);
        AssessmentSummary summary = summarize(safeFindings);
        int totalBehaviors = Math.max(0, discoveredImplementationBehaviors);
        int rawAssessedBehaviors = implementationFindingCount(safeFindings);
        int assessedBehaviors = Math.min(totalBehaviors, rawAssessedBehaviors);
        int unresolvedBehaviors = Math.max(0, totalBehaviors - assessedBehaviors);
        boolean complete = totalBehaviors >= MINIMUM_COMPLETE_BEHAVIORS && rawAssessedBehaviors == totalBehaviors
                && safeFindings.stream().noneMatch(finding -> typeOf(finding) == DifferenceType.REQUIRES_REVIEW);

        int documented = summary.correctCount() + summary.conditionalCount() + summary.incorrectCount();
        int accuracy = percentage(summary.correctCount() + summary.conditionalCount() * 0.5, documented);
        int coverage = percentage(documented, totalBehaviors);
        int baseScore = percentage(summary.correctCount() + summary.conditionalCount() * 0.5, totalBehaviors);
        int riskAdjustedScore = clamp(baseScore - materialRiskPenalty(safeFindings));
        Integer overallScore = complete ? riskAdjustedScore : null;
        int confidence = evidenceConfidence(safeFindings, totalBehaviors, assessedBehaviors);

        DimensionScores dimensions = new DimensionScores(
                dimensionScore(safeFindings, AssessmentDimension.BUSINESS_LOGIC_ALIGNMENT),
                coverage,
                dimensionScore(safeFindings, AssessmentDimension.TECHNICAL_ACCURACY),
                dimensionScore(safeFindings, AssessmentDimension.OPERATIONAL_ACCURACY));
        AssessmentStatus status = complete
                ? applyRiskOverride(statusFor(riskAdjustedScore), safeFindings)
                : AssessmentStatus.ASSESSMENT_INCOMPLETE;

        return new AssessmentResult(overallScore, status, accuracy, coverage, confidence, complete,
                totalBehaviors, assessedBehaviors, unresolvedBehaviors, dimensions, summary,
                recommendationFor(status));
    }

    public AssessmentStatus statusFor(int score) {
        int bounded = clamp(score);
        if (bounded >= 90) return AssessmentStatus.ALIGNED;
        if (bounded >= 75) return AssessmentStatus.MOSTLY_ALIGNED;
        if (bounded >= 60) return AssessmentStatus.NEEDS_REVIEW;
        return AssessmentStatus.MATERIALLY_MISALIGNED;
    }

    private List<ComparisonFinding> safe(List<ComparisonFinding> findings) {
        return findings == null ? List.of() : findings;
    }

    private int implementationFindingCount(List<ComparisonFinding> findings) {
        return (int) findings.stream().filter(this::representsImplementationBehavior).count();
    }

    private boolean representsImplementationBehavior(ComparisonFinding finding) {
        DifferenceType type = typeOf(finding);
        if (type == DifferenceType.DOCUMENT_ONLY || type == DifferenceType.REQUIRES_REVIEW) return false;
        return finding.codeEvidence() != null && !finding.codeEvidence().isEmpty();
    }

    private DifferenceType typeOf(ComparisonFinding finding) {
        return finding.type() == null ? DifferenceType.REQUIRES_REVIEW : finding.type();
    }

    private int percentage(double numerator, int denominator) {
        if (denominator <= 0) return 0;
        return clamp((int) Math.round(numerator / denominator * 100));
    }

    private int materialRiskPenalty(List<ComparisonFinding> findings) {
        int penalty = 0;
        for (ComparisonFinding finding : findings) {
            if (!isGap(typeOf(finding))) continue;
            if (finding.severity() == Severity.CRITICAL) penalty += 10;
            if (finding.severity() == Severity.HIGH) penalty += 5;
        }
        return Math.min(30, penalty);
    }

    private AssessmentStatus applyRiskOverride(AssessmentStatus calculated, List<ComparisonFinding> findings) {
        boolean critical = findings.stream().anyMatch(finding -> isGap(typeOf(finding))
                && finding.severity() == Severity.CRITICAL);
        long high = findings.stream().filter(finding -> isGap(typeOf(finding))
                && finding.severity() == Severity.HIGH).count();
        if (critical || high >= 2) {
            if (calculated == AssessmentStatus.ALIGNED || calculated == AssessmentStatus.MOSTLY_ALIGNED)
                return AssessmentStatus.NEEDS_REVIEW;
        }
        if (high == 1 && calculated == AssessmentStatus.ALIGNED)
            return AssessmentStatus.MOSTLY_ALIGNED;
        return calculated;
    }

    private int evidenceConfidence(List<ComparisonFinding> findings, int total, int assessed) {
        if (total == 0 || assessed == 0) return 0;
        int confidenceTotal = 0;
        int counted = 0;
        for (ComparisonFinding finding : findings) {
            if (!representsImplementationBehavior(finding)) continue;
            int confidence = 60;
            if (hasDocumentEvidence(finding)) confidence += 30;
            DifferenceType type = typeOf(finding);
            if (type == DifferenceType.CONDITIONAL) confidence -= 10;
            if (type == DifferenceType.REQUIRES_REVIEW) confidence -= 25;
            confidenceTotal += clamp(confidence);
            counted++;
        }
        int directEvidenceConfidence = counted == 0 ? 0 : confidenceTotal / counted;
        return clamp((int) Math.round(directEvidenceConfidence * (assessed / (double) total)));
    }

    private boolean hasDocumentEvidence(ComparisonFinding finding) {
        String evidence = finding.documentEvidence();
        return evidence != null && !evidence.isBlank()
                && !evidence.equalsIgnoreCase("No matching documentation found");
    }

    private Integer dimensionScore(List<ComparisonFinding> findings, AssessmentDimension dimension) {
        List<ComparisonFinding> dimensionFindings = findings.stream()
                .filter(this::representsImplementationBehavior)
                .filter(finding -> resolveDimension(finding) == dimension)
                .toList();
        if (dimensionFindings.isEmpty()) return null;
        double points = dimensionFindings.stream().mapToDouble(this::alignmentWeight).sum();
        return percentage(points, dimensionFindings.size());
    }

    private double alignmentWeight(ComparisonFinding finding) {
        return switch (typeOf(finding)) {
            case MATCHED, CORRECT -> 1.0;
            case CONDITIONAL -> 0.5;
            default -> 0.0;
        };
    }

    private AssessmentDimension resolveDimension(ComparisonFinding finding) {
        if (finding.assessmentDimension() != null) return finding.assessmentDimension();
        if (finding.type() == DifferenceType.TECHNICAL_DETAIL_MISSING)
            return AssessmentDimension.TECHNICAL_ACCURACY;
        if (finding.type() == DifferenceType.MISSING_IN_DOCUMENT)
            return AssessmentDimension.DOCUMENTATION_COMPLETENESS;
        String category = ((finding.category() == null ? "" : finding.category()) + " "
                + (finding.businessCapability() == null ? "" : finding.businessCapability()))
                .toLowerCase(Locale.ROOT);
        if (containsAny(category, "database", "api", "integration", "kafka", "component", "technical"))
            return AssessmentDimension.TECHNICAL_ACCURACY;
        if (containsAny(category, "operation", "error", "exception", "state", "concurrency", "message"))
            return AssessmentDimension.OPERATIONAL_ACCURACY;
        return AssessmentDimension.BUSINESS_LOGIC_ALIGNMENT;
    }

    private boolean containsAny(String value, String... terms) {
        for (String term : terms) if (value.contains(term)) return true;
        return false;
    }

    private boolean isGap(DifferenceType type) {
        return type != DifferenceType.MATCHED && type != DifferenceType.CORRECT;
    }

    private AssessmentSummary summarize(List<ComparisonFinding> findings) {
        int correct = 0, conditional = 0, incorrect = 0, missing = 0, critical = 0, high = 0;
        for (ComparisonFinding finding : findings) {
            DifferenceType type = typeOf(finding);
            if (type == DifferenceType.MATCHED || type == DifferenceType.CORRECT) correct++;
            if (type == DifferenceType.CONDITIONAL) conditional++;
            if (type == DifferenceType.INCORRECT || type == DifferenceType.OUTDATED_DOCUMENTATION
                    || type == DifferenceType.DOCUMENT_ONLY || type == DifferenceType.IMPLEMENTATION_CHANGED
                    || type == DifferenceType.INCONSISTENT_RULE) incorrect++;
            if (type == DifferenceType.MISSING_IN_DOCUMENT || type == DifferenceType.TECHNICAL_DETAIL_MISSING)
                missing++;
            if (finding.severity() == Severity.CRITICAL) critical++;
            if (finding.severity() == Severity.HIGH) high++;
        }
        return new AssessmentSummary(correct, conditional, incorrect, missing, critical, high);
    }

    private String recommendationFor(AssessmentStatus status) {
        return switch (status) {
            case ALIGNED -> "Documentation accurately represents the assessed implementation behaviour with no material gaps identified.";
            case MOSTLY_ALIGNED -> "Documentation is broadly consistent with the implementation, but identified gaps should be addressed.";
            case NEEDS_REVIEW -> "Material documentation gaps or inconsistencies exist and should be remediated before approval.";
            case MATERIALLY_MISALIGNED -> "Documentation does not reliably represent the current implementation and should not be approved as-is.";
            case ASSESSMENT_INCOMPLETE -> "Available evidence is insufficient to determine overall documentation alignment reliably.";
        };
    }

    private int clamp(int value) { return Math.max(0, Math.min(100, value)); }
}
