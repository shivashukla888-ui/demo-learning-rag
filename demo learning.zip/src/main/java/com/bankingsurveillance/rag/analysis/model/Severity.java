package com.bankingsurveillance.rag.analysis.model;

public enum Severity { CRITICAL, HIGH, MEDIUM, LOW }
