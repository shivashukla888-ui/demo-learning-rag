package com.bankingsurveillance.rag.analysis.model;
public record AssessmentResult(Integer overallScore, AssessmentStatus status,
                               int accuracy, int coverage, int evidenceConfidence,
                               boolean assessmentComplete, int totalBehaviors,
                               int assessedBehaviors, int unresolvedBehaviors,
                               DimensionScores dimensionScores, AssessmentSummary summary,
                               String recommendation) { }
