package com.bankingsurveillance.rag.analysis.model;
public record AssessmentSummary(int correctCount, int conditionalCount, int incorrectCount,
                                int missingCount, int criticalCount, int highCount) {
    public int criticalHighRiskCount() { return criticalCount + highCount; }
}
