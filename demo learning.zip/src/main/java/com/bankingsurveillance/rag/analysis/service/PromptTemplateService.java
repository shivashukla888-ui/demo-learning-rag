package com.bankingsurveillance.rag.analysis.service;

import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Map;

@Component
public class PromptTemplateService {
    private final ResourceLoader resourceLoader;

    public PromptTemplateService(ResourceLoader resourceLoader) {
        this.resourceLoader = resourceLoader;
    }

    public String render(String name, Map<String, String> values) {
        try {
            String template = resourceLoader.getResource("classpath:prompts/" + name)
                    .getContentAsString(StandardCharsets.UTF_8);
            for (Map.Entry<String, String> value : values.entrySet()) {
                template = template.replace("{{" + value.getKey() + "}}", value.getValue());
            }
            return template;
        } catch (IOException exception) {
            throw new IllegalStateException("Could not load prompt template " + name, exception);
        }
    }
}
