package com.bankingsurveillance.rag.analysis.model;

import java.util.List;

public record CodeKnowledgeModel(List<CodeKnowledgeItem> items) {
    public CodeKnowledgeModel {
        items = items == null ? List.of() : List.copyOf(items);
    }
}
