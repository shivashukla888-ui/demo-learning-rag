package com.bankingsurveillance.rag.analysis.model;

import java.util.List;

public record CodeKnowledgeItem(String category, String businessCapability, String behavior,
                                List<CodeEvidence> evidence) {
    public CodeKnowledgeItem {
        evidence = evidence == null ? List.of() : List.copyOf(evidence);
    }
}
