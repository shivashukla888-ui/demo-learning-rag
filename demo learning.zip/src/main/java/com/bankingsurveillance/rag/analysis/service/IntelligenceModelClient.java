package com.bankingsurveillance.rag.analysis.service;

public interface IntelligenceModelClient {
    <T> T generate(String prompt, Class<T> responseType);
    String generateText(String prompt);
}
