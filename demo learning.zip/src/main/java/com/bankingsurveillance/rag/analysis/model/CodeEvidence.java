package com.bankingsurveillance.rag.analysis.model;

public record CodeEvidence(String source, String symbol, String behavior) { }
