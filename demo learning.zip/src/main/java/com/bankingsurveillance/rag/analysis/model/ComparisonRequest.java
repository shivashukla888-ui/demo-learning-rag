package com.bankingsurveillance.rag.analysis.model;

public record ComparisonRequest(String feature, String repository, String documentSource) {
    public ComparisonRequest(String feature) {
        this(feature, null, null);
    }
}
