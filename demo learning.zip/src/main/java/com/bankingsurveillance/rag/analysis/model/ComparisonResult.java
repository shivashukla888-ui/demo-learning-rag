package com.bankingsurveillance.rag.analysis.model;

public record ComparisonResult(StructuredDifferenceReport structuredReport,
                               AssessmentResult assessment,
                               String markdownReport,
                               String updatedDocumentContent) {
    public ComparisonResult(StructuredDifferenceReport structuredReport,
                            String markdownReport, String updatedDocumentContent) {
        this(structuredReport, null, markdownReport, updatedDocumentContent);
    }
}
