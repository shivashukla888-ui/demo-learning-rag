package com.bankingsurveillance.rag.analysis.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.stereotype.Component;

@Component
public class SpringAiIntelligenceModelClient implements IntelligenceModelClient {
    private final ChatClient chatClient;
    private final ObjectMapper objectMapper;

    public SpringAiIntelligenceModelClient(ChatClient.Builder builder, ObjectMapper objectMapper) {
        this.chatClient = builder.build();
        this.objectMapper = objectMapper;
    }

    @Override
    public <T> T generate(String prompt, Class<T> responseType) {
        try {
            return objectMapper.readValue(stripFence(generateText(prompt)), responseType);
        } catch (JsonProcessingException exception) {
            throw new IllegalStateException("The model returned invalid structured JSON", exception);
        }
    }

    @Override
    public String generateText(String prompt) {
        return chatClient.prompt().user(prompt).call().content();
    }

    private String stripFence(String response) {
        String value = response == null ? "" : response.trim();
        if (!value.startsWith("```")) return value;
        int firstLineEnd = value.indexOf('\n');
        int closingFence = value.lastIndexOf("```");
        return firstLineEnd >= 0 && closingFence > firstLineEnd
                ? value.substring(firstLineEnd + 1, closingFence).trim() : value;
    }
}
