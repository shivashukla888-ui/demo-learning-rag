package com.bankingsurveillance.rag.analysis.model;
public enum AssessmentDimension { BUSINESS_LOGIC_ALIGNMENT, DOCUMENTATION_COMPLETENESS, TECHNICAL_ACCURACY, OPERATIONAL_ACCURACY }
