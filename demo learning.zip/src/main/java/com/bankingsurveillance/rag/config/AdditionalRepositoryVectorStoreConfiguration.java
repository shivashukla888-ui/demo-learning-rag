package com.bankingsurveillance.rag.config;

import org.springframework.ai.embedding.EmbeddingModel;
import org.springframework.ai.vectorstore.PgVectorStore;
import org.springframework.ai.vectorstore.VectorStore;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;

@Configuration
public class AdditionalRepositoryVectorStoreConfiguration {

    @Bean("tradingSurveillanceCodeVectorStore")
    public VectorStore tradingSurveillanceCodeVectorStore(
            JdbcTemplate jdbcTemplate, EmbeddingModel embeddingModel) {
        return new PgVectorStore("trading_surveillance_code_store_v2", jdbcTemplate, embeddingModel, 1536,
                PgVectorStore.PgDistanceType.COSINE_DISTANCE, false,
                PgVectorStore.PgIndexType.HNSW, true);
    }
}
