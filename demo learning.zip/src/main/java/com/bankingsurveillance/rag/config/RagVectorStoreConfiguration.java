package com.bankingsurveillance.rag.config;

import org.springframework.ai.embedding.EmbeddingModel;
import org.springframework.ai.vectorstore.PgVectorStore;
import org.springframework.ai.vectorstore.VectorStore;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;

@Configuration
public class RagVectorStoreConfiguration {

    @Bean("pdfVectorStore")
    public VectorStore pdfVectorStore(JdbcTemplate jdbcTemplate, EmbeddingModel embeddingModel) {
        return createStore("banking_pdf_store", jdbcTemplate, embeddingModel);
    }

    @Bean("codeVectorStore")
    public VectorStore codeVectorStore(JdbcTemplate jdbcTemplate, EmbeddingModel embeddingModel) {
        return createStore("wash_trading_code_store", jdbcTemplate, embeddingModel);
    }

    private VectorStore createStore(String tableName, JdbcTemplate jdbcTemplate, EmbeddingModel embeddingModel) {
        PgVectorStore store = new PgVectorStore(tableName, jdbcTemplate, embeddingModel, 1536,
                PgVectorStore.PgDistanceType.COSINE_DISTANCE, false,
                PgVectorStore.PgIndexType.HNSW, true);
        return store;
    }
}
