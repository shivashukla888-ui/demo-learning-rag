# Wash Trading Surveillance

Standalone Java 21 domain service used as source code for code-to-document RAG analysis.

## Implemented behavior

- Maintains an independent rolling trade history for each account.
- Removes trades older than the configured surveillance window.
- Detects opposite-side trades for the same account and instrument.
- Requires prices to be within the configured relative tolerance.
- Emits one `WASH_TRADING_SUSPECT` alert containing both matching trade identifiers.
- Validates trade identity, account, symbol, price, quantity, side, and timestamp.
- Supports concurrent accounts and serializes updates to each account history.

## Run tests

```bash
mvn test
```

This module has no dependency on the RAG application or Spring.
