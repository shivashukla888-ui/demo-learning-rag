package com.bank.surveillance.domain;

import java.time.Instant;
import java.util.Objects;

public record Alert(String alertId, String accountId, String alertType,
                    Instant raisedAt, String description) {
    public Alert {
        Objects.requireNonNull(alertId, "alertId must not be null");
        Objects.requireNonNull(accountId, "accountId must not be null");
        Objects.requireNonNull(alertType, "alertType must not be null");
        Objects.requireNonNull(raisedAt, "raisedAt must not be null");
        Objects.requireNonNull(description, "description must not be null");
    }
}
