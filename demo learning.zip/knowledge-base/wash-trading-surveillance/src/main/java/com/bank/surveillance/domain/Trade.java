package com.bank.surveillance.domain;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.Objects;

public record Trade(String tradeId, String accountId, String symbol, BigDecimal price,
                    long quantity, TradeSide side, Instant timestamp) {
    public Trade {
        requireText(tradeId, "tradeId");
        requireText(accountId, "accountId");
        requireText(symbol, "symbol");
        Objects.requireNonNull(price, "price must not be null");
        Objects.requireNonNull(side, "side must not be null");
        Objects.requireNonNull(timestamp, "timestamp must not be null");
        if (price.signum() < 0) throw new IllegalArgumentException("price must not be negative");
        if (quantity <= 0) throw new IllegalArgumentException("quantity must be positive");
    }

    private static void requireText(String value, String field) {
        if (value == null || value.isBlank()) throw new IllegalArgumentException(field + " must not be blank");
    }
}
