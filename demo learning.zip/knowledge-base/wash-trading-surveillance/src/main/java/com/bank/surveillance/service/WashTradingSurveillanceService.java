package com.bank.surveillance.service;

import com.bank.surveillance.domain.Alert;
import com.bank.surveillance.domain.Trade;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Clock;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class WashTradingSurveillanceService {
    public static final String ALERT_TYPE = "WASH_TRADING_SUSPECT";

    private final long timeWindowMs;
    private final BigDecimal priceTolerance;
    private final Clock clock;
    private final Map<String, List<Trade>> accountTradeHistory = new ConcurrentHashMap<>();

    public WashTradingSurveillanceService(long timeWindowMs, double priceTolerancePct) {
        this(timeWindowMs, BigDecimal.valueOf(priceTolerancePct), Clock.systemUTC());
    }

    public WashTradingSurveillanceService(long timeWindowMs, BigDecimal priceTolerance, Clock clock) {
        if (timeWindowMs <= 0) throw new IllegalArgumentException("timeWindowMs must be positive");
        if (priceTolerance == null || priceTolerance.signum() < 0)
            throw new IllegalArgumentException("priceTolerance must not be negative");
        this.timeWindowMs = timeWindowMs;
        this.priceTolerance = priceTolerance;
        this.clock = clock;
    }

    public Optional<Alert> evaluateTrade(Trade incomingTrade) {
        if (incomingTrade == null) throw new IllegalArgumentException("incomingTrade must not be null");
        List<Trade> history = accountTradeHistory.computeIfAbsent(
                incomingTrade.accountId(), ignored -> new ArrayList<>());
        synchronized (history) {
            cleanOldTrades(history, incomingTrade.timestamp());
            Optional<Alert> alert = detectWashTrade(incomingTrade, history);
            history.add(incomingTrade);
            return alert;
        }
    }

    private void cleanOldTrades(List<Trade> history, Instant currentTimestamp) {
        long cutoff = currentTimestamp.toEpochMilli() - timeWindowMs;
        history.removeIf(trade -> trade.timestamp().toEpochMilli() < cutoff);
    }

    private Optional<Alert> detectWashTrade(Trade latest, List<Trade> history) {
        for (Trade past : history) {
            boolean oppositeSide = past.side().isOpposite(latest.side());
            boolean sameInstrument = past.symbol().equals(latest.symbol());
            boolean priceMatches = isPriceWithinTolerance(past.price(), latest.price());
            if (oppositeSide && sameInstrument && priceMatches) {
                return Optional.of(new Alert(UUID.randomUUID().toString(), latest.accountId(), ALERT_TYPE,
                        clock.instant(), "Matching opposite trades found: %s and %s"
                        .formatted(past.tradeId(), latest.tradeId())));
            }
        }
        return Optional.empty();
    }

    private boolean isPriceWithinTolerance(BigDecimal first, BigDecimal second) {
        BigDecimal average = first.add(second).divide(BigDecimal.valueOf(2), 8, RoundingMode.HALF_UP);
        if (average.signum() == 0) return true;
        BigDecimal percentageDifference = first.subtract(second).abs()
                .divide(average, 8, RoundingMode.HALF_UP);
        return percentageDifference.compareTo(priceTolerance) <= 0;
    }

    public int retainedTradeCount(String accountId) {
        List<Trade> history = accountTradeHistory.get(accountId);
        if (history == null) return 0;
        synchronized (history) {
            return history.size();
        }
    }
}
