package com.bank.surveillance.domain;

public enum TradeSide {
    BUY, SELL;

    public boolean isOpposite(TradeSide other) {
        return other != null && this != other;
    }
}
