package com.bank.surveillance.service;

import com.bank.surveillance.domain.Alert;
import com.bank.surveillance.domain.Trade;
import com.bank.surveillance.domain.TradeSide;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.Clock;
import java.time.Instant;
import java.time.ZoneOffset;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

class WashTradingSurveillanceServiceTest {
    private static final Instant NOW = Instant.parse("2026-08-20T10:00:00Z");
    private final WashTradingSurveillanceService service = new WashTradingSurveillanceService(
            60_000, new BigDecimal("0.01"), Clock.fixed(NOW, ZoneOffset.UTC));

    @Test
    void raisesAlertForOppositeTradesWithinPriceTolerance() {
        assertFalse(service.evaluateTrade(trade("T1", "A1", "ABC", "100.00", TradeSide.BUY, NOW)).isPresent());
        Optional<Alert> result = service.evaluateTrade(
                trade("T2", "A1", "ABC", "100.50", TradeSide.SELL, NOW.plusSeconds(10)));
        assertTrue(result.isPresent());
        assertEquals(WashTradingSurveillanceService.ALERT_TYPE, result.orElseThrow().alertType());
        assertEquals(NOW, result.orElseThrow().raisedAt());
    }

    @Test
    void doesNotMatchSameSideDifferentInstrumentOrDifferentAccount() {
        service.evaluateTrade(trade("T1", "A1", "ABC", "100", TradeSide.BUY, NOW));
        assertFalse(service.evaluateTrade(trade("T2", "A1", "ABC", "100", TradeSide.BUY, NOW)).isPresent());
        assertFalse(service.evaluateTrade(trade("T3", "A1", "XYZ", "100", TradeSide.SELL, NOW)).isPresent());
        assertFalse(service.evaluateTrade(trade("T4", "A2", "ABC", "100", TradeSide.SELL, NOW)).isPresent());
    }

    @Test
    void excludesTradesOutsideConfiguredWindow() {
        service.evaluateTrade(trade("T1", "A1", "ABC", "100", TradeSide.BUY, NOW));
        assertFalse(service.evaluateTrade(
                trade("T2", "A1", "ABC", "100", TradeSide.SELL, NOW.plusSeconds(61))).isPresent());
        assertEquals(1, service.retainedTradeCount("A1"));
    }

    @Test
    void rejectsInvalidTradesAndConfiguration() {
        assertThrows(IllegalArgumentException.class, () -> new WashTradingSurveillanceService(0, 0.01));
        assertThrows(IllegalArgumentException.class,
                () -> trade("T1", "A1", "ABC", "100", TradeSide.BUY, NOW, 0));
    }

    private Trade trade(String id, String account, String symbol, String price,
                        TradeSide side, Instant timestamp) {
        return trade(id, account, symbol, price, side, timestamp, 10);
    }

    private Trade trade(String id, String account, String symbol, String price,
                        TradeSide side, Instant timestamp, long quantity) {
        return new Trade(id, account, symbol, new BigDecimal(price), quantity, side, timestamp);
    }
}
