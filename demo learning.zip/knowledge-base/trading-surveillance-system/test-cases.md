# Trading Surveillance System - Test Cases

This document provides a comprehensive set of test inputs to verify all anomaly detectors in the system. Use these JSON payloads in ActiveMQ to test each scenario.

## Testing Instructions
1. Configure your ActiveMQ broker at `tcp://localhost:61616` with default credentials (admin/admin)
2. Start your application
3. Use the ActiveMQ web console (typically at http://localhost:8161/admin) to send messages
4. Copy each JSON payload and send it to the `TRADE_INPUT` queue
5. Check the application logs or console for alerts and processing results

## Input Format

The system expects JSON messages in the following format, or in batches wrapped by "[]":

```json
{
  "tradeId": "string",
  "symbol": "string",
  "price": number,
  "quantity": number,
  "traderId": "string",
  "counterpartyId": "string",
  "assetType": "string",
  "timestamp": "YYYY-MM-DDTHH:mm:ss",
  "tradeType": "string",
  "executed": boolean
}
```

Send these messages to the `TRADE_INPUT` queue in ActiveMQ.

## 1. Flash Crash Detection Test Cases

Flash crashes are detected when a rapid, significant price drop occurs within a short time window (10 seconds, 20% drop threshold).

### 1.1 Normal Trading (No Flash Crash)

Expected behavior: No alerts should be generated as the price drop is small (less than 1%).

```json
[
  {
    "tradeId": "T1001",
    "symbol": "AAPL",
    "price": 180.50,
    "quantity": 100,
    "traderId": "TR001",
    "counterpartyId": "CP001",
    "assetType": "stock",
    "timestamp": "2023-06-01T10:00:00",
    "tradeType": "buy",
    "executed": true
  },
  {
    "tradeId": "T1002",
    "symbol": "AAPL",
    "price": 180.25,
    "quantity": 50,
    "traderId": "TR002",
    "counterpartyId": "CP002",
    "assetType": "stock",
    "timestamp": "2023-06-01T10:00:05",
    "tradeType": "sell",
    "executed": true
  }
]
```

### 1.2 Flash Crash Scenario

Expected behavior: Should trigger a FLASH_CRASH alert as the price drops 22% (from 250.00 to 195.00) within 7 seconds.

```json
[
  {
    "tradeId": "T1003",
    "symbol": "TSLA",
    "price": 250.00,
    "quantity": 100,
    "traderId": "TR003",
    "counterpartyId": "CP003",
    "assetType": "stock",
    "timestamp": "2023-06-01T11:00:00",
    "tradeType": "buy",
    "executed": true
  },
  {
    "tradeId": "T1004",
    "symbol": "TSLA",
    "price": 245.00,
    "quantity": 50,
    "traderId": "TR004",
    "counterpartyId": "CP004",
    "assetType": "stock",
    "timestamp": "2023-06-01T11:00:03",
    "tradeType": "sell",
    "executed": true
  },
  {
    "tradeId": "T1005",
    "symbol": "TSLA",
    "price": 195.00,
    "quantity": 200,
    "traderId": "TR005",
    "counterpartyId": "CP005",
    "assetType": "stock",
    "timestamp": "2023-06-01T11:00:07",
    "tradeType": "sell",
    "executed": true
  }
]
```

### 1.3 Flash Crash in Bonds

Expected behavior: Should trigger a FLASH_CRASH alert as the price drops 21% (from 100.00 to 79.00) within 8 seconds.

```json
[
  {
    "tradeId": "T1006",
    "symbol": "US10Y",
    "price": 100.00,
    "quantity": 1000,
    "traderId": "TR006",
    "counterpartyId": "CP006",
    "assetType": "bond",
    "timestamp": "2023-06-01T12:00:00",
    "tradeType": "buy",
    "executed": true
  },
  {
    "tradeId": "T1007",
    "symbol": "US10Y",
    "price": 79.00,
    "quantity": 500,
    "traderId": "TR007",
    "counterpartyId": "CP007",
    "assetType": "bond",
    "timestamp": "2023-06-01T12:00:08",
    "tradeType": "sell",
    "executed": true
  }
]
```

### 1.4 Flash Crash Test with Unsupported Asset Type

Expected behavior: No alerts should be generated because "forex" is not in the supported asset types for flash crash detection. However, a invalid message exception should be thrown. The messages should also enter the dead letter queue.

```json
[
  {
    "tradeId": "T1008",
    "symbol": "EUR/USD",
    "price": 1.2000,
    "quantity": 10000,
    "traderId": "TR008",
    "counterpartyId": "CP008",
    "assetType": "forex",
    "timestamp": "2023-06-01T13:00:00",
    "tradeType": "buy",
    "executed": true
  },
  {
    "tradeId": "T1009",
    "symbol": "EUR/USD",
    "price": 0.9000,
    "quantity": 10000,
    "traderId": "TR009",
    "counterpartyId": "CP009",
    "assetType": "forex",
    "timestamp": "2023-06-01T13:00:05",
    "tradeType": "sell",
    "executed": true
  }
]
```

## 2. Wash Trade Detection Test Cases

Wash trades are detected when the same entity is both buyer and seller.

### 2.1 Normal Trading (No Wash Trade)

Expected behavior: No alerts should be generated as the trader and counterparty are different entities.

```json
{
  "tradeId": "T2001",
  "symbol": "MSFT",
  "price": 350.00,
  "quantity": 100,
  "traderId": "TR101",
  "counterpartyId": "CP101",
  "assetType": "stock",
  "timestamp": "2023-06-02T10:00:00",
  "tradeType": "buy",
  "executed": true
}
```

### 2.2 Wash Trade in Stocks

Expected behavior: Should trigger a WASH_TRADE alert as the trader and counterparty IDs are identical.

```json
{
  "tradeId": "T2002",
  "symbol": "MSFT",
  "price": 350.00,
  "quantity": 50,
  "traderId": "TR102",
  "counterpartyId": "TR102",
  "assetType": "stock",
  "timestamp": "2023-06-02T10:15:00",
  "tradeType": "buy",
  "executed": true
}
```

### 2.3 Wash Trade in Crypto

Expected behavior: Should trigger a WASH_TRADE alert as the trader and counterparty IDs are identical.

```json
{
  "tradeId": "T2003",
  "symbol": "BTC/USD",
  "price": 50000.00,
  "quantity": 2,
  "traderId": "TR103",
  "counterpartyId": "TR103",
  "assetType": "crypto",
  "timestamp": "2023-06-02T11:00:00",
  "tradeType": "sell",
  "executed": true
}
```

### 2.4 Wash Trade in Bonds

Expected behavior: Should trigger a WASH_TRADE alert as the trader and counterparty IDs are identical.

```json
{
  "tradeId": "T2004",
  "symbol": "US30Y",
  "price": 98.50,
  "quantity": 500,
  "traderId": "TR104",
  "counterpartyId": "TR104",
  "assetType": "bond",
  "timestamp": "2023-06-02T12:00:00",
  "tradeType": "buy",
  "executed": true
}
```

## 3. Spoofing Detection Test Cases

Spoofing is detected when a trader places multiple large, unexecuted orders in a short time window (3+ orders of 1000+ quantity within 10 seconds).

### 3.1 Normal Trading (No Spoofing)

Expected behavior: No alerts should be generated as this is a single order with quantity below the spoofing threshold.

```json
{
  "tradeId": "T3001",
  "symbol": "ETH/USD",
  "price": 3000.00,
  "quantity": 500,
  "traderId": "TR201",
  "counterpartyId": "CP201",
  "assetType": "crypto",
  "timestamp": "2023-06-03T10:00:00",
  "tradeType": "buy",
  "executed": false
}
```

### 3.2 Spoofing in Crypto

Expected behavior: Should trigger a SPOOFING alert as there are 3 unexecuted orders with quantities exceeding 1000 within a 7-second window.

```json
[
  {
    "tradeId": "T3002",
    "symbol": "BTC/USD",
    "price": 60000.00,
    "quantity": 1200,
    "traderId": "TR202",
    "counterpartyId": "CP202",
    "assetType": "crypto",
    "timestamp": "2023-06-03T11:00:00",
    "tradeType": "buy",
    "executed": false
  },
  {
    "tradeId": "T3003",
    "symbol": "BTC/USD",
    "price": 60100.00,
    "quantity": 1500,
    "traderId": "TR202",
    "counterpartyId": "CP203",
    "assetType": "crypto",
    "timestamp": "2023-06-03T11:00:03",
    "tradeType": "buy",
    "executed": false
  },
  {
    "tradeId": "T3004",
    "symbol": "BTC/USD",
    "price": 60200.00,
    "quantity": 2000,
    "traderId": "TR202",
    "counterpartyId": "CP204",
    "assetType": "crypto",
    "timestamp": "2023-06-03T11:00:07",
    "tradeType": "buy",
    "executed": false
  }
]
```

### 3.3 Spoofing Test with Executed Orders (Should Not Trigger)

Expected behavior: No alerts should be generated because these orders are executed, and spoofing only applies to unexecuted orders.

```json
[
  {
    "tradeId": "T3005",
    "symbol": "BTC/USD",
    "price": 61000.00,
    "quantity": 1200,
    "traderId": "TR203",
    "counterpartyId": "CP205",
    "assetType": "crypto",
    "timestamp": "2023-06-03T12:00:00",
    "tradeType": "buy",
    "executed": true
  },
  {
    "tradeId": "T3006",
    "symbol": "BTC/USD",
    "price": 61100.00,
    "quantity": 1500,
    "traderId": "TR203",
    "counterpartyId": "CP206",
    "assetType": "crypto",
    "timestamp": "2023-06-03T12:00:03",
    "tradeType": "buy",
    "executed": true
  },
  {
    "tradeId": "T3007",
    "symbol": "BTC/USD",
    "price": 61200.00,
    "quantity": 2000,
    "traderId": "TR203",
    "counterpartyId": "CP207",
    "assetType": "crypto",
    "timestamp": "2023-06-03T12:00:07",
    "tradeType": "buy",
    "executed": true
  }
]
```

### 3.4 Spoofing Test with Unsupported Asset Type (Should Not Trigger)

Expected behavior: No alerts should be generated because "stock" is not supported for spoofing detection (only crypto is supported).

```json
[
  {
    "tradeId": "T3008",
    "symbol": "AAPL",
    "price": 190.00,
    "quantity": 1200,
    "traderId": "TR204",
    "counterpartyId": "CP208",
    "assetType": "stock",
    "timestamp": "2023-06-03T13:00:00",
    "tradeType": "buy",
    "executed": false
  },
  {
    "tradeId": "T3009",
    "symbol": "AAPL",
    "price": 190.50,
    "quantity": 1500,
    "traderId": "TR204",
    "counterpartyId": "CP209",
    "assetType": "stock",
    "timestamp": "2023-06-03T13:00:03",
    "tradeType": "buy",
    "executed": false
  },
  {
    "tradeId": "T3010",
    "symbol": "AAPL",
    "price": 191.00,
    "quantity": 2000,
    "traderId": "TR204",
    "counterpartyId": "CP210",
    "assetType": "stock",
    "timestamp": "2023-06-03T13:00:07",
    "tradeType": "buy",
    "executed": false
  }
]
```

## 4. Momentum Ignition Detection Test Cases

Momentum ignition is detected when there are 3+ trades in the same direction with climbing prices within a 5-second window.

### 4.1 Normal Trading (No Momentum Ignition)

Expected behavior: No alerts should be generated because there are only 2 trades (minimum 3 required) and the price is decreasing rather than climbing.

```json
[
  {
    "tradeId": "T4001",
    "symbol": "NVDA",
    "price": 800.00,
    "quantity": 100,
    "traderId": "TR301",
    "counterpartyId": "CP301",
    "assetType": "stock",
    "timestamp": "2023-06-04T10:00:00",
    "tradeType": "buy",
    "executed": true
  },
  {
    "tradeId": "T4002",
    "symbol": "NVDA",
    "price": 798.00,
    "quantity": 50,
    "traderId": "TR301",
    "counterpartyId": "CP302",
    "assetType": "stock",
    "timestamp": "2023-06-04T10:00:03",
    "tradeType": "buy",
    "executed": true
  }
]
```

### 4.2 Momentum Ignition in Stocks

Expected behavior: Should trigger a MOMENTUM_IGNITION alert as there are 3 trades in the same direction with climbing prices (180 → 182 → 185) within a 4-second window.

```json
[
  {
    "tradeId": "T4003",
    "symbol": "AMZN",
    "price": 180.00,
    "quantity": 100,
    "traderId": "TR302",
    "counterpartyId": "CP303",
    "assetType": "stock",
    "timestamp": "2023-06-04T11:00:00",
    "tradeType": "buy",
    "executed": true
  },
  {
    "tradeId": "T4004",
    "symbol": "AMZN",
    "price": 182.00,
    "quantity": 150,
    "traderId": "TR302",
    "counterpartyId": "CP304",
    "assetType": "stock",
    "timestamp": "2023-06-04T11:00:02",
    "tradeType": "buy",
    "executed": true
  },
  {
    "tradeId": "T4005",
    "symbol": "AMZN",
    "price": 185.00,
    "quantity": 200,
    "traderId": "TR302",
    "counterpartyId": "CP305",
    "assetType": "stock",
    "timestamp": "2023-06-04T11:00:04",
    "tradeType": "buy",
    "executed": true
  }
]
```

### 4.3 Momentum Ignition in Crypto

Expected behavior: Should trigger a MOMENTUM_IGNITION alert as there are 3 trades in the same direction with climbing prices (3000 → 3020 → 3050) within a 4-second window.

```json
[
  {
    "tradeId": "T4006",
    "symbol": "ETH/USD",
    "price": 3000.00,
    "quantity": 10,
    "traderId": "TR303",
    "counterpartyId": "CP306",
    "assetType": "crypto",
    "timestamp": "2023-06-04T12:00:00",
    "tradeType": "buy",
    "executed": true
  },
  {
    "tradeId": "T4007",
    "symbol": "ETH/USD",
    "price": 3020.00,
    "quantity": 15,
    "traderId": "TR303",
    "counterpartyId": "CP307",
    "assetType": "crypto",
    "timestamp": "2023-06-04T12:00:02",
    "tradeType": "buy",
    "executed": true
  },
  {
    "tradeId": "T4008",
    "symbol": "ETH/USD",
    "price": 3050.00,
    "quantity": 20,
    "traderId": "TR303",
    "counterpartyId": "CP308",
    "assetType": "crypto",
    "timestamp": "2023-06-04T12:00:04",
    "tradeType": "buy",
    "executed": true
  }
]
```

### 4.4 Momentum Ignition Test with Different Directions (Should Not Trigger)

Expected behavior: No alerts should be generated because the trade directions are mixed (buy, sell, buy), not all in the same direction.

```json
[
  {
    "tradeId": "T4009",
    "symbol": "META",
    "price": 450.00,
    "quantity": 100,
    "traderId": "TR304",
    "counterpartyId": "CP309",
    "assetType": "stock",
    "timestamp": "2023-06-04T13:00:00",
    "tradeType": "buy",
    "executed": true
  },
  {
    "tradeId": "T4010",
    "symbol": "META",
    "price": 455.00,
    "quantity": 150,
    "traderId": "TR304",
    "counterpartyId": "CP310",
    "assetType": "stock",
    "timestamp": "2023-06-04T13:00:02",
    "tradeType": "sell",
    "executed": true
  },
  {
    "tradeId": "T4011",
    "symbol": "META",
    "price": 460.00,
    "quantity": 200,
    "traderId": "TR304",
    "counterpartyId": "CP311",
    "assetType": "stock",
    "timestamp": "2023-06-04T13:00:04",
    "tradeType": "buy",
    "executed": true
  }
]
```

## 5. Edge Cases and Error Testing

### 5.1 Invalid Trade (Missing Required Fields)

Expected behavior: This trade should be rejected and routed to the dead letter handler because it's missing required fields (quantity, traderId, etc.).

```json
{
  "tradeId": "T6001",
  "symbol": "AAPL",
  "price": 190.00
}
```

### 5.2 Invalid Asset Type

Expected behavior: This trade should be filtered out by the `MessageFilter` processor because the asset type is not in the supported list.

```json
{
  "tradeId": "T6002",
  "symbol": "AAPL",
  "price": 190.00,
  "quantity": 100,
  "traderId": "TR501",
  "counterpartyId": "CP501",
  "assetType": "unknown",
  "timestamp": "2023-06-06T10:00:00",
  "tradeType": "buy",
  "executed": true
}
```

### 5.3 Trade Amount Below Filter Threshold

Expected behavior: This trade should be filtered out because the total trade amount (price × quantity = 950) is below the minimum threshold of 1000.

```json
{
  "tradeId": "T6003",
  "symbol": "AAPL",
  "price": 190.00,
  "quantity": 5,
  "traderId": "TR502",
  "counterpartyId": "CP502",
  "assetType": "stock",
  "timestamp": "2023-06-06T10:05:00",
  "tradeType": "buy",
  "executed": true
}
```

### 5.4 Invalid Date Format

Expected behavior: This trade should be rejected and routed to the dead letter handler because of the invalid timestamp format.

```json
{
  "tradeId": "T6004",
  "symbol": "AAPL",
  "price": 190.00,
  "quantity": 100,
  "traderId": "TR503",
  "counterpartyId": "CP503",
  "assetType": "stock",
  "timestamp": "06/06/2023",
  "tradeType": "buy",
  "executed": true
}
```