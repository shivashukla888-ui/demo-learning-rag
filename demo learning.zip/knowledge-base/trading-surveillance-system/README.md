# Trading Surveillance System

A real-time market surveillance application designed to detect market manipulation and anomalous trading patterns using Apache Camel and Spring Boot.

## Overview

This system monitors trading activity by consuming trade messages from ActiveMQ queues, validating them, and running various anomaly detection algorithms to identify potentially manipulative trading behaviors such as:

- **Flash Crashes**: Rapid, significant price declines in securities over a very short time period
- **Momentum Ignition**: Creating artificial price movements by aggressively trading to trigger stop-loss orders or algorithmic trading responses
- **Wash Trades**: Transactions where the same entity acts as both buyer and seller, creating false market activity
- **Spoofing**: Placing and quickly canceling large orders to create a false impression of market sentiment

When suspicious activity is detected, the system generates alerts that can be routed to appropriate stakeholders.

## Technologies

- Java 17
- Spring Boot 3.4.6
- Apache Camel 4.11.0
- ActiveMQ

## Architecture

The application follows a message-driven architecture built on Enterprise Integration Patterns (EIP):

1. **Message Consumption**: 
   - Trades are consumed from ActiveMQ queues
   - Messages enter the system through the "TRADE_INPUT" queue

2. **Processing Pipeline**: 
   - **Batch Trade Splitting**: Messages are parsed and split into individual trades (Splitter EIP)
   - **Message Validation**: Trades undergo validation through a chain of validators (Chain of Responsibility pattern)
   - **Message Filtering**: Trades below configured thresholds are filtered out (Content Filter EIP)
   - **Anomaly Detection**: Valid trades are routed to appropriate detectors (Content-Based Router EIP)

3. **Alert Generation and Distribution**: 
   - Detected anomalies trigger alert creation (Builder pattern)
   - Alerts are distributed to multiple subscribers (Observer pattern, Publish-Subscribe Channel EIP)
   - High severity alerts trigger email notifications

## Design Patterns & EIPs

### Design Patterns
The system implements the following design patterns:

1. **Singleton Pattern**:
   - `ConfigCenter`: Ensures a single configuration instance throughout the application

2. **Strategy Pattern**:
   - `AnomalyDetector` interface with implementations like `FlashCrashDetector`, `SpoofingDetector`
   - Allows dynamic selection of detection algorithms based on trade characteristics

3. **Observer Pattern**:
   - `AlertDispatcher` (subject) notifies `AlertSubscriber` implementations (observers)
   - Enables flexible alert distribution to console, log files, and email

4. **Builder Pattern**:
   - `AlertBuilder`: Simplifies the construction of complex Alert objects

5. **Chain of Responsibility Pattern**:
   - `TradeValidator` chain: Validators process trades sequentially
   - Each validator focuses on a specific validation aspect

### EIPs
The system leverages the following EIPs:

1. **Splitter**:
   - `BatchTradeSplitter`: Splits batch messages into individual trades
   - Camel's `.split(body())` operation in the route

2. **Content Filter**:
   - `MessageFilter`: Filters out trades with amounts below threshold
   - Implemented with Camel's filter mechanism

3. **Dead Letter Channel**:
   - `DeadLetterHandler`: Handles invalid trades
   - Routes invalid messages to "TRADE_DEAD_LETTER" queue

4. **Publish-Subscribe Channel**:
   - `AlertDispatcher`: Distributes alerts to multiple subscribers
   - Enables multiple alert handling strategies simultaneously

5. **Canonical Data Model**:
   - `CanonicalTrade`: Standardized trade model for all system processing
   - Ensures consistent data representation throughout the pipeline

6. **Content-Based Router**:
   - `DetectionEngine`: Routes trades to appropriate detectors
   - Uses the `supports()` method to determine routing

### ***Pattern/EIP - Class Mapping***
![Pattern/EIP - Class Mapping](src/main/resources/static/image/DP_EIP.png "Pattern/EIP - Class Mapping")

## Message Flow

1. Trade messages arrive at the "TRADE_INPUT" ActiveMQ queue
2. `BatchTradeSplitter` parses the message and converts to `CanonicalTrade` objects
3. `MessageValidator` validates trades using a chain of validators
4. `MessageFilter` filters out trades below the configured threshold
5. `UnifiedDetectionProcessor` processes valid trades through the `DetectionEngine`
6. `DetectionEngine` routes trades to appropriate detectors based on trade characteristics
7. Detectors analyze trades and generate alerts when anomalies are detected
8. `AlertDispatcher` distributes alerts to all subscribers
9. Subscribers handle alerts according to their implementation (console output, log file, email)

### ***Flow Chart***
![Flow Chart](src/main/resources/static/image/flow_uml.png "Flow Chart UML")


## Getting Started

### Prerequisites

- JDK 17 or higher
- Maven
- ActiveMQ (running locally or accessible)

### Setup

1. Clone the repository:
   ```
   git clone https://github.com/andrewyying/final-project-andrewyying.git
   ```

2. Navigate to the project directory:
   ```
   cd final-project-andrewyying
   ```

3. Edit `src/main/resources/application.yml` to configure ActiveMQ connection details

4. Build the project:
   ```
   mvn clean install
   ```

5. Run the application:
   ```
   mvn spring-boot:run
   ```

### Configuration

1. Edit `src/main/resources/application.yml` to configure:
    - ActiveMQ connection details
    - Application-specific settings

2. Edit `src/main/resources/config/config.yml` to configure:
    - Detection thresholds and parameters
    - Filtering criteria
    - Email notification settings
    - Supported asset types

## Usage

1. Send trade messages to the `TRADE_INPUT` queue. Messages should conform to the `CanonicalTrade` model structure. A comprehensive list of test cases is provided in [test-cases.md](test-cases.md), along with further instructions and explanations.

2. The system processes incoming messages and generates:
   - Console output for all alerts
   - Log entries in `src/main/resources/alert/alerts.log`
   - Email notifications for high severity alerts

3. Invalid messages are sent to the `TRADE_DEAD_LETTER` queue fotr further analysis.

## Project Structure

- `model/` - Data models like `CanonicalTrade` and `Alert`
- `detector/` - Various market manipulation detection algorithms
- `processor/` - Camel processors for handling trade messages
- `validation/` - Trade validation components
- `subscriber/` - Alert subscription services
- `alert/` - Alert management services
- `util/` - Utility classes including configuration management

### Class Diagram
![Class Diagram](src/main/resources/static/image/class_uml.png "Class Diagram")