package com.github.andrewyying.finalprojectandrewyying;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinalProjectAndrewyyingApplicationTests {

    @Test
    void contextLoads() {
    }

}
