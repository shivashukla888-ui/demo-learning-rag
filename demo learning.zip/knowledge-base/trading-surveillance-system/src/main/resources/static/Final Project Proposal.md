# Final Project Proposal - Trading Surveillance System

### *General Topic*

This project proposes the development of a real-time trading surveillance system that monitors financial transactions to
detect anomalies such as wash trades, flash crashes, and price manipulation. Detected issues will be sent as alerts to a
risk monitoring front-end (dashboard, email, or SMS). The project aligns with my summer internship focus and serves as
valuable preparation

### *Problem Description*

Modern markets generate thousands of trades per second, making manual oversight infeasible. This system will simulate
real-time trading data and apply automated, rule-based anomaly detection using Apache Camel and ActiveMQ. Trade messages
will be standardized, routed by asset type, filtered for relevance, and evaluated using modular strategies. Alerts will
be pushed asynchronously, and invalid messages handled through a dead letter channel.

This system will simulate live trade records and execute multiple layers of analysis, including consuming live or
simulated transaction messages via ActiveMQ queues; translating diverse message formats into a canonical trade format;
dynamically routing trades to appropriate detectors based on asset class; executing anomaly detection strategies;
generating structured alerts; managing and logging messages through a dead letter channel; etc.

### *EIPs to be Leveraged (How, Why, and Where)*

1. **Content-Based Router**: Directs each trade to the appropriate detection engine based on asset type or market
   metadata, ensuring specialized logic is applied after message translation and before detection
2. **Message Translator**: Standardizes raw input like CSV or JSON into internal trade objects, enabling consistent
   processing immediately after message ingestion
3. **Message Filter**: Removes trivial or low-risk trades before analysis to reduce processing load, and is applied just
   prior to routing trades for detection
4. **Dead Letter Channel**: Captures malformed or invalid messages that fail validation, preserving main flow integrity
   and logging errors as soon as they occur
5. **Event-Driven Consumer**: Pushes anomaly alerts to subscribed risk systems / team in real time, enabling
   asynchronous handling right after alert generation
6. **Splitter**: Decomposes batched input into individual trade events early in the pipeline, allowing detection logic
   to operate on single-trade granularity

### *Design Patterns to be Leveraged (How, Why, and Where)*

1. **Strategy**: Allows pluggable detection algorithms for different anomaly types, invoked during the trade analysis
   stage for flexibility and reuse
2. **Template Method**: defines a common detection workflow with customizable steps, used across all anomaly detectors
   to maintain structure and consistency
3. **Singleton**: Provides a shared configuration source for thresholds and rules, accessed by various modules at
   runtime to ensure consistency
4. **Observer**: Notifies subscribed alert handlers immediately upon anomaly detection, promoting real-time and
   decoupled alert delivery
5. **Command**: Encapsulate alert actions into executable units for dispatch, enabling logging, retries, and rollback
   during the alert handling process.

### *Anticipated Deliverables*

The full system will contain approximately 20-25 classes, organized into the following major components:

- **Trade Ingestion**: Includes classes like `TradeReceiver`, `FileReader`, or `KafkaTradeConsumer`, responsible for
  ingesting trade data from files, message queues (e.g., ActiveMQ), or streaming platforms (e.g., Kafka)
- **Translation and Routing**: Consists of `TradeTranslator` (for converting raw input to CanonicalTrade objects) and
  `TradeRouter`, which uses asset type or metadata to direct trades to the appropriate detector modules via Camel routes
- **Detection Engine**: Includes an abstract `AnomalyDetector` base class with concrete strategy implementations like
  `WashTradeDetector`, `FlashCrashDetector`, `SpoofingDetector`, and more. These detectors may be managed by a
  `DetectionEngine` coordinator that applies selected strategies
- **Alert Dispatcher and Classifier**: Comprises classes like `AlertBuilder`, `AlertSeverityClassifier`, and
  `AlertCommand`, responsible for packaging alerts, assigning severity levels, and dispatching to downstream consumers
  or systems
- **Notification**: Includes mock consumer classes like `AlertSubscriber`, `EmailNotifier`, etc., which represent end
  systems that receive and display alerts via event-driven subscription
- **Error and Exception Handling**: Contains `DeadLetterHandler` for logging and isolating invalid trade messages, along
  with centralized exception management utilities like `ValidationException` and `MessageErrorLogger`

### *Activity UML Demonstration*

See separately attached.