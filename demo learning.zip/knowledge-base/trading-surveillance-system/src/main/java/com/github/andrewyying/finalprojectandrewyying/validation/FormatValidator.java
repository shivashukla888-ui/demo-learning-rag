package com.github.andrewyying.finalprojectandrewyying.validation;

import com.github.andrewyying.finalprojectandrewyying.model.CanonicalTrade;
import com.github.andrewyying.finalprojectandrewyying.exception.InvalidTradeException;

/**
 * Validator that checks if a trade has all the required fields properly populated.
 * Ensures that no required fields are null or empty.
 */
public class FormatValidator implements TradeValidator {
    private TradeValidator next; // The next validator in the chain

    @Override
    public void setNext(TradeValidator next) {
        this.next = next;
    }

    /**
     * Validates that all required fields in the trade are properly populated.
     * Checks for null or empty values in essential trade attributes.
     * Passes the trade to the next validator if it passes all validations.
     *
     * @param trade The trade to validate
     * @throws InvalidTradeException If any required field is missing or empty
     */
    @Override
    public void handle(CanonicalTrade trade) throws InvalidTradeException {
        if (trade.getTradeId() == null || trade.getTradeId().isEmpty()) {
            throw new InvalidTradeException("Trade ID is missing.");
        }
        if (trade.getAssetType() == null || trade.getAssetType().isEmpty()) {
            throw new InvalidTradeException("Asset Type is missing.");
        }
        if (trade.getTimestamp() == null) {
            throw new InvalidTradeException("Timestamp is missing.");
        }
        if (trade.getTraderId() == null || trade.getTraderId().isEmpty()) {
            throw new InvalidTradeException("Trader ID is missing.");
        }
        if (trade.getCounterpartyId() == null || trade.getCounterpartyId().isEmpty()) {
            throw new InvalidTradeException("Counterparty ID is missing.");
        }
        if (trade.getSymbol() == null || trade.getSymbol().isEmpty()) {
            throw new InvalidTradeException("Symbol is missing.");
        }
        if (trade.getTradeType() == null || trade.getTradeType().isEmpty()) {
            throw new InvalidTradeException("Trade type is missing.");
        }
        if (next != null) {
            next.handle(trade); // Pass to next validator if all validations pass
        }
    }
}