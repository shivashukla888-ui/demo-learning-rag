package com.github.andrewyying.finalprojectandrewyying.subscriber;

import com.github.andrewyying.finalprojectandrewyying.model.Alert;
import org.springframework.stereotype.Component;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.format.DateTimeFormatter;

/**
 * Subscriber that logs alerts to a file.
 * Records all alerts in a persistent log file for historical tracking and analysis.
 */
@Component
public class LogFileSubscriber implements AlertSubscriber {

    private static final String LOG_FILE_PATH = "src/main/resources/alerts/alerts.log"; // Path to the log file

    // Static initializer to ensure the log directory exists
    static {
        File file = new File(LOG_FILE_PATH);
        file.getParentFile().mkdirs(); // Create parent directories if they don't exist
    }

    /**
     * Handles an alert by writing it to the log file.
     * Formats the alert and appends it to the existing log file.
     * 
     * @param alert The alert to log to the file
     */
    @Override
    public void onAlert(Alert alert) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(LOG_FILE_PATH, true))) {
            writer.println(formatAlert(alert)); // Write the formatted alert to the log file
        } catch (IOException e) {
            System.err.println("Failed to write alert to log file: " + e.getMessage());
        }
    }

    /**
     * Formats an alert into a standardized log entry string.
     * Creates a human-readable log entry with timestamp, severity, message, and trade details.
     * 
     * @param alert The alert to format
     * @return A formatted string representation of the alert suitable for logging
     */
    private String formatAlert(Alert alert) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        return String.format("[%s] [%s] %s | Trade id: %s | Executed at '%s'",
                alert.getAlertTime().format(formatter), // Format the alert timestamp
                alert.getSeverity(), // Include the alert severity
                alert.getMessage(), // Include the alert message
                alert.getTradeId(), // Include the associated trade ID
                alert.getTradeTime().format(formatter) // Format the trade timestamp
        );
    }
}