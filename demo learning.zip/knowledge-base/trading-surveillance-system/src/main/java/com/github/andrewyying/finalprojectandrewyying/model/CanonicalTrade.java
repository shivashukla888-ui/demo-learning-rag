package com.github.andrewyying.finalprojectandrewyying.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * Represents a standardized trade in the system.
 * This class serves as the canonical model for trade data throughout the application,
 * containing all essential information about a trade transaction.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CanonicalTrade {
    private String tradeId; // Unique identifier for the trade
    private String symbol; // Trading symbol or ticker of the asset
    private double price; // Price per unit of the asset
    private int quantity; // Number of units in the trade
    private String traderId; // ID of the trader initiating the trade
    private String counterpartyId; // ID of the counterparty in the trade
    private String assetType; // Type of asset being traded (e.g., "stock", "crypto")
    private LocalDateTime timestamp; // When the trade occurred
    private String tradeType; // Direction of the trade (e.g., "buy", "sell")
    private boolean executed; // Whether the trade has been executed

    @Override
    public String toString() {
        return "CanonicalTrade{" +
                "tradeId='" + tradeId + '\'' +
                ", symbol='" + symbol + '\'' +
                ", price=" + price +
                ", quantity=" + quantity +
                ", traderId='" + traderId + '\'' +
                ", counterpartyId='" + counterpartyId + '\'' +
                ", assetType='" + assetType + '\'' +
                ", timestamp=" + timestamp +
                ", tradeType='" + tradeType + '\'' +
                ", executed='" + executed + '\'' +
                '}';
    }
}
