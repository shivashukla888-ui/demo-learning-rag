package com.github.andrewyying.finalprojectandrewyying.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * Represents an alert generated for a trade.
 * This class stores information about alerts including the trade details,
 * alert type, severity, message, and timestamps.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Alert {
    private String tradeId;         // The unique identifier of the trade associated with this alert
    private LocalDateTime tradeTime; // The timestamp when the trade was executed
    private String alertType;       // The type of alert (e.g., "WASH_TRADE", "FLASH_CRASH", etc.)
    private String severity;        // The severity level of the alert (e.g., "LOW", "MEDIUM", "HIGH", "CRITICAL")
    private String message;         // The detailed message describing the alert
    private LocalDateTime alertTime; // The timestamp when the alert was generated

    @Override
    public String toString() {
        return "Alert{" +
                "tradeId='" + tradeId + '\'' +
                "tradeTime='" + tradeTime + '\'' +
                ", alertType='" + alertType + '\'' +
                ", severity='" + severity + '\'' +
                ", message='" + message + '\'' +
                ", alertTime=" + alertTime +
                '}';
    }
}
