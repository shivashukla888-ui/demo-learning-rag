package com.github.andrewyying.finalprojectandrewyying.detector;

import com.github.andrewyying.finalprojectandrewyying.alert.AlertBuilder;
import com.github.andrewyying.finalprojectandrewyying.model.Alert;
import com.github.andrewyying.finalprojectandrewyying.model.CanonicalTrade;
import com.github.andrewyying.finalprojectandrewyying.util.ConfigCenter;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.*;

/**
 * Detector for identifying momentum ignition patterns in trading activity.
 * Momentum ignition occurs when a trader rapidly executes multiple trades in the same direction
 * to create artificial price momentum, potentially to trigger other market participants' algorithms.
 */
@Component
public class MomentumIgnitionDetector implements AnomalyDetector {
    // Key: traderId|symbol, Value: recent trades
    private static final Map<String, List<TradeRecord>> recentTrades = new HashMap<>();

    /**
     * Determines if this detector supports the given trade's asset type.
     * Checks configuration to see if momentum ignition detection is enabled for this asset type.
     * 
     * @param trade The trade to check for support
     * @return true if momentum ignition detection is supported for this asset type, false otherwise
     */
    @Override
    public boolean supports(CanonicalTrade trade) {
        ConfigCenter config = ConfigCenter.getInstance();
        List<String> supportedAssets = config.getMomentumIgnitionSupportedAssets();
        return supportedAssets.stream().anyMatch(type -> type.equalsIgnoreCase(trade.getAssetType()));
    }

    /**
     * Detects momentum ignition by analyzing patterns of trades from the same trader on the same symbol.
     * Alerts are generated when a trader executes multiple trades in the same direction with climbing prices.
     * 
     * @param trade The trade to analyze
     * @return An Optional containing an Alert if momentum ignition is detected, or empty otherwise
     */
    @Override
    public Optional<Alert> detect(CanonicalTrade trade) {

        ConfigCenter config = ConfigCenter.getInstance();
        int timeWindow = config.getMomentumIgnitionTimeWindow();
        int minTradeCount = config.getMomentumIgnitionMinCount();

        if (!trade.isExecuted()) {
            return Optional.empty();
        }

        if (!supports(trade)) {
            return Optional.empty();
        }

        String traderId = trade.getTraderId();
        String symbol = trade.getSymbol();
        String key = traderId + "|" + symbol;

        LocalDateTime referenceTime = trade.getTimestamp();
        TradeRecord current = new TradeRecord(
                trade.getTradeId(),
                referenceTime,
                trade.getPrice(),
                trade.getTradeType()
        );

        List<TradeRecord> history = recentTrades.computeIfAbsent(key, k -> new ArrayList<>());
        history.removeIf(r -> r.timestamp.plusSeconds(timeWindow).isBefore(referenceTime));
        history.add(current);

        if (history.size() >= minTradeCount &&
                allSameDirection(history) &&
                isPriceClimbing(history)) {

            return Optional.of(AlertBuilder.build(
                    "MOMENTUM_IGNITION",
                    "Detected rapid directional price push for " + symbol + " by trader " + traderId,
                    trade
            ));
        }

        return Optional.empty();
    }

    /**
     * Checks if all trades in the list have the same direction (buy/sell).
     * 
     * @param trades List of trades to check
     * @return true if all trades have the same direction, false otherwise
     */
    private boolean allSameDirection(List<TradeRecord> trades) {
        String direction = trades.get(0).direction;
        return trades.stream().allMatch(t -> t.direction.equals(direction));
    }

    /**
     * Checks if prices are consistently increasing across the list of trades.
     * 
     * @param trades List of trades to check
     * @return true if prices are consistently climbing, false otherwise
     */
    private boolean isPriceClimbing(List<TradeRecord> trades) {
        for (int i = 1; i < trades.size(); i++) {
            if (trades.get(i).price < trades.get(i - 1).price) {
                return false;
            }
        }
        return true;
    }

    /**
     * Inner class representing a trade record for momentum ignition detection.
     * Stores the essential information needed to identify directional trading patterns.
     */
    @AllArgsConstructor
    private static class TradeRecord { // Inner class specifically for this type of trade
        String tradeID;
        LocalDateTime timestamp;
        double price;
        String direction;

        @Override
        public String toString() {
            String timeStr = timestamp
                    .atZone(ZoneId.systemDefault())
                    .format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));

            return "TradeRecord(tradeID=" + tradeID +
                    ", timestamp=" + timeStr +
                    ", price=" + price +
                    ", direction=" + direction + ")";
        }
    }
}