package com.github.andrewyying.finalprojectandrewyying.detector;

import com.github.andrewyying.finalprojectandrewyying.alert.AlertBuilder;
import com.github.andrewyying.finalprojectandrewyying.model.Alert;
import com.github.andrewyying.finalprojectandrewyying.model.CanonicalTrade;
import com.github.andrewyying.finalprojectandrewyying.util.ConfigCenter;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;

/**
 * Detector for identifying wash trades in the system.
 * A wash trade occurs when a trader trades with themselves, potentially
 * to create artificial market activity or manipulate prices.
 */
@Component
public class WashTradeDetector implements AnomalyDetector {
    /**
     * Detects wash trades by checking if the trader ID matches the counterparty ID.
     * 
     * @param trade The trade to analyze
     * @return An Optional containing an Alert if a wash trade is detected, or empty otherwise
     */
    @Override
    public Optional<Alert> detect(CanonicalTrade trade) {
        // Simplified logic - if the trader is trading with themselves => wash trade
        if (trade.getTraderId().equals(trade.getCounterpartyId())) {
            return Optional.of(AlertBuilder.build("WASH_TRADE", "Trader is trading with themselves", trade));
        } else {
            return Optional.empty();
        }
    }

    /**
     * Determines if this detector supports the given trade's asset type.
     * Checks configuration to see if wash trade detection is enabled for this asset type.
     * 
     * @param trade The trade to check for support
     * @return true if wash trade detection is supported for this asset type, false otherwise
     */
    @Override
    public boolean supports(CanonicalTrade trade) {
        ConfigCenter config = ConfigCenter.getInstance(); // Get configuration settings
        List<String> supportedAssets = config.getWashTradeSupportedAssets(); // Get assets that support wash trade detection
        return supportedAssets.stream().anyMatch(type -> type.equalsIgnoreCase(trade.getAssetType()));
    }
}