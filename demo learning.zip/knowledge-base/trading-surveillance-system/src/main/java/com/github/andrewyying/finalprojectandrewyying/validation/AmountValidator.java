package com.github.andrewyying.finalprojectandrewyying.validation;

import com.github.andrewyying.finalprojectandrewyying.exception.InvalidTradeException;
import com.github.andrewyying.finalprojectandrewyying.model.CanonicalTrade;

/**
 * Validator that checks if the trade amount (price and quantity) is valid.
 * Ensures that both price and quantity are positive values.
 */
public class AmountValidator implements TradeValidator {
    private TradeValidator next; // The next validator in the chain

    @Override
    public void setNext(TradeValidator next) {
        this.next = next;
    }

    /**
     * Validates that the trade has positive price and quantity.
     * Passes the trade to the next validator if it passes this validation.
     *
     * @param trade The trade to validate
     * @throws InvalidTradeException If the price or quantity is not positive
     */
    @Override
    public void handle(CanonicalTrade trade) throws InvalidTradeException {
        if (trade.getPrice() <= 0 || trade.getQuantity() <= 0) {
            throw new InvalidTradeException("Trade price and quantity must be positive.");
        }
        if (next != null) {
            next.handle(trade); // Pass to next validator if validation passes
        }
    }
}