package com.github.andrewyying.finalprojectandrewyying.processor;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;

/**
 * Processor that handles invalid trade messages by routing them to a dead letter queue.
 * Logs error information and forwards the original message to a dedicated error queue.
 */
public class DeadLetterHandler implements Processor {
    /**
     * Processes an exchange containing an invalid message.
     * Extracts the exception and original message, logs error details,
     * and forwards the message to the dead letter queue.
     *
     * @param exchange The Camel exchange containing the invalid message
     */
    @Override
    public void process(Exchange exchange) {
        Exception exception = exchange.getProperty(Exchange.EXCEPTION_CAUGHT, Exception.class);
        String rawMessage = exchange.getIn().getBody(String.class);

        System.err.println("⚠️ Invalid message caught: " + rawMessage);
        System.err.println("Reason: " + exception.getMessage());

        exchange.getContext().createProducerTemplate().sendBody("activemq:queue:TRADE_DEAD_LETTER", rawMessage);
    }
}
