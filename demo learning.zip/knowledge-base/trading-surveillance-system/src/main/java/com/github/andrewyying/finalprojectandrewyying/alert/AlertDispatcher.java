package com.github.andrewyying.finalprojectandrewyying.alert;

import com.github.andrewyying.finalprojectandrewyying.subscriber.AlertSubscriber;
import com.github.andrewyying.finalprojectandrewyying.model.Alert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Component responsible for dispatching alerts to all registered subscribers.
 * Implements the Observer pattern to notify subscribers when alerts are generated.
 */
@Component
public class AlertDispatcher {

    private final List<AlertSubscriber> subscribers; // List of subscribers that will receive alerts

    /**
     * Constructs a new AlertDispatcher with the provided list of subscribers.
     *
     * @param subscribers List of alert subscribers to notify
     */
    @Autowired
    public AlertDispatcher(List<AlertSubscriber> subscribers) {
        this.subscribers = subscribers;
    }

    /**
     * Dispatches an alert to all registered subscribers.
     * Each subscriber's onAlert method is called with the alert.
     *
     * @param alert The alert to dispatch to all subscribers
     */
    public void dispatch(Alert alert) {
        subscribers.forEach(subscriber -> subscriber.onAlert(alert)); // Notify each subscriber
    }
}
