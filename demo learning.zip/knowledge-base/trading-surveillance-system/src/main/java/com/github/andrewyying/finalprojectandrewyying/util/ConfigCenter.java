package com.github.andrewyying.finalprojectandrewyying.util;

import lombok.Getter;
import org.yaml.snakeyaml.Yaml;
import java.io.InputStream;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Singleton configuration center that manages all system settings.
 * Loads configuration from a YAML file and provides access to various
 * settings used throughout the application.
 */
@Getter
public class ConfigCenter {

    // Singleton instance
    private static final ConfigCenter INSTANCE = new ConfigCenter();

    // Spoofing
    private int spoofingTimeWindow; // Time window in seconds for spoofing detection
    private int spoofingMinQuantity; // Minimum quantity threshold for spoofing detection
    private int spoofingMinCount; // Minimum count of large orders to trigger spoofing alert
    private List<String> spoofingSupportedAssets; // Asset types that support spoofing detection
    private String spoofingSeverity; // Severity level for spoofing alerts

    // Wash trade
    private List<String> washTradeSupportedAssets; // Asset types that support wash trade detection
    private String washTradeSeverity; // Severity level for wash trade alerts

    // Flash crash
    private int flashCrashTimeWindow; // Time window in seconds for flash crash detection
    private double flashCrashPriceDropThreshold; // Price drop percentage threshold for flash crash detection
    private List<String> flashCrashSupportedAssets; // Asset types that support flash crash detection
    private String flashTradeSeverity; // Severity level for flash crash alerts

    // Momentum Ignition
    private int momentumIgnitionTimeWindow; // Time window in seconds for momentum ignition detection
    private int momentumIgnitionMinCount; // Minimum trade count to trigger momentum ignition alert
    private List<String> momentumIgnitionSupportedAssets; // Asset types that support momentum ignition detection
    private String momentumIgnitionSeverity; // Severity level for momentum ignition alerts

    // Alert severity
    private String defaultSeverity; // Default severity level for alerts when not specified

    // Message filter
    private double filterMinTradeAmount; // Minimum trade amount (price * quantity) to pass the filter

    // Emails
    private List<String> alertEmailRecipient; // List of email recipients for alert notifications

    // Asset Types
    private Set<String> supportedAssetTypes; // Set of all supported asset types in the system

    /**
     * Private constructor to enforce singleton pattern.
     * Loads configuration from the YAML file upon initialization.
     */
    private ConfigCenter() {
        loadConfig();
    }

    /**
     * Gets the singleton instance of the ConfigCenter.
     * 
     * @return The singleton ConfigCenter instance
     */
    public static ConfigCenter getInstance() {
        return INSTANCE;
    }

    /**
     * Loads configuration settings from the YAML file.
     * Parses the configuration file and populates the configuration properties.
     * 
     * @throws RuntimeException If the configuration file is not found or cannot be parsed
     */
    @SuppressWarnings("unchecked")
    private void loadConfig() {
        InputStream input = getClass().getClassLoader().getResourceAsStream("config/config.yml");
        if (input == null) {
            throw new RuntimeException("config.yaml not found under resources/config/");
        }

        try {
            Yaml yaml = new Yaml();
            Map<String, Object> config = yaml.load(input); // Load the YAML configuration

            // Parse spoofing configuration
            Map<String, Object> spoofing = (Map<String, Object>) config.get("spoofing");
            spoofingTimeWindow = (int) spoofing.get("timeWindowSeconds");
            spoofingMinQuantity = (int) spoofing.get("minQuantityThreshold");
            spoofingMinCount = (int) spoofing.get("minSpoofingCount");
            spoofingSupportedAssets = (List<String>) spoofing.get("supportedAssetTypes");
            spoofingSeverity = (String) spoofing.get("severity");

            // Parse wash trade configuration
            Map<String, Object> washTrade = (Map<String, Object>) config.get("washTrade");
            washTradeSupportedAssets = (List<String>) washTrade.get("supportedAssetTypes");
            washTradeSeverity = (String) spoofing.get("severity");

            // Parse flash crash configuration
            Map<String, Object> flashCrash = (Map<String, Object>) config.get("flashCrash");
            flashCrashTimeWindow = (int) flashCrash.get("timeWindowSeconds");
            flashCrashPriceDropThreshold = (double) flashCrash.get("priceDropThreshold");
            flashCrashSupportedAssets = (List<String>) flashCrash.get("supportedAssetTypes");
            flashTradeSeverity = (String) flashCrash.get("severity");

            // Parse momentum ignition configuration
            Map<String, Object> momentumIgnition = (Map<String, Object>) config.get("momentumIgnition");
            momentumIgnitionTimeWindow = (int) momentumIgnition.get("timeWindowSeconds");
            momentumIgnitionMinCount = (int) momentumIgnition.get("minTradeCount");
            momentumIgnitionSupportedAssets = (List<String>) momentumIgnition.get("supportedAssetTypes");
            momentumIgnitionSeverity = (String) momentumIgnition.get("severity");

            defaultSeverity = (String) config.get("alertDefaultSeverity");

            // Parse filter configuration
            Map<String, Object> filter = (Map<String, Object>) config.get("filter");
            filterMinTradeAmount = (double) filter.get("minTradeAmount");

            // Parse email configuration
            alertEmailRecipient = (List<String>) config.get("alertEmailRecipient");

            // Parse supported asset types
            List<String> assetList = (List<String>) config.get("supportedAssetTypes");
            supportedAssetTypes = new HashSet<>(assetList); // Convert to Set for efficient lookups

        } catch (Exception e) {
            throw new RuntimeException("Failed to load config.yaml", e);
        }
    }

}
