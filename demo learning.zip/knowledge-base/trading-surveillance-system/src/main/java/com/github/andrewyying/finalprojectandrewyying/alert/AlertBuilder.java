package com.github.andrewyying.finalprojectandrewyying.alert;

import com.github.andrewyying.finalprojectandrewyying.model.Alert;
import com.github.andrewyying.finalprojectandrewyying.model.CanonicalTrade;

import java.time.LocalDateTime;

/**
 * Builder class for creating Alert objects from trade data.
 * Simplifies the process of creating standardized alerts with consistent formatting.
 */
public class AlertBuilder {

    /**
     * Builds an Alert object with the specified parameters and derived values.
     * Sets the alert time to the current time and determines severity based on alert type.
     *
     * @param alertType The type of alert being created
     * @param message Descriptive message explaining the alert
     * @param trade The trade that triggered the alert
     * @return A fully populated Alert object
     */
    public static Alert build(String alertType, String message, CanonicalTrade trade){
        Alert alert = new Alert();
        alert.setAlertType(alertType);
        alert.setMessage(message);
        alert.setTradeId(trade.getTradeId());
        alert.setAlertTime(LocalDateTime.now());
        alert.setTradeTime(trade.getTimestamp());
        alert.setSeverity(AlertSeverityClassifier.classify(alert));
        return alert;
    }
}
