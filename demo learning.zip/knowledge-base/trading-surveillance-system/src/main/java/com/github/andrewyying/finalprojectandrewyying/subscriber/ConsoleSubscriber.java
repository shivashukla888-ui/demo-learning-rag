package com.github.andrewyying.finalprojectandrewyying.subscriber;

import com.github.andrewyying.finalprojectandrewyying.model.Alert;
import org.springframework.stereotype.Component;

/**
 * Subscriber that outputs alerts to the console.
 * Provides a simple way to display alerts in the system console for debugging
 * and monitoring purposes.
 */
@Component
public class ConsoleSubscriber implements AlertSubscriber {
    /**
     * Handles an alert by printing its details to the system console.
     * Formats the alert information in a readable format with type, severity, and message.
     * 
     * @param alert The alert to output to the console
     */
    public void onAlert(Alert alert) {
        System.out.println("Received Alert:");
        System.out.println("- Type: " + alert.getAlertType()); // Print the alert type
        System.out.println("- Severity: " + alert.getSeverity()); // Print the alert severity
        System.out.println("- Message: " + alert.getMessage()); // Print the alert message
    }
}
