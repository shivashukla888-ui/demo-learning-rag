package com.github.andrewyying.finalprojectandrewyying.detector;

import com.github.andrewyying.finalprojectandrewyying.alert.AlertBuilder;
import com.github.andrewyying.finalprojectandrewyying.model.Alert;
import com.github.andrewyying.finalprojectandrewyying.model.CanonicalTrade;
import com.github.andrewyying.finalprojectandrewyying.util.ConfigCenter;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.*;

/**
 * Detector for identifying spoofing patterns in trading activity.
 * Spoofing occurs when a trader places a large number of orders they don't intend to execute,
 * typically to create a false impression of market activity and manipulate prices.
 */
@Component
public class SpoofingDetector implements AnomalyDetector {

    // Recent trades of traders, keyed by trader ID
    private static final Map<String, List<TradeRecord>> recentTrades = new HashMap<>();

    /**
     * Detects potential spoofing by analyzing patterns of unexecuted orders from the same trader.
     * Alerts are generated when a trader places multiple large unexecuted orders within a configured time window.
     * 
     * @param trade The trade to analyze
     * @return An Optional containing an Alert if spoofing is detected, or empty otherwise
     */
    @Override
    public Optional<Alert> detect(CanonicalTrade trade) {

        ConfigCenter config = ConfigCenter.getInstance();
        int timeWindow = config.getSpoofingTimeWindow(); // Time window in seconds to look for pattern
        int minQuantity = config.getSpoofingMinQuantity(); // Minimum quantity to consider as a large order
        int minCount = config.getSpoofingMinCount(); // Minimum number of large orders to trigger an alert

        if (!supports(trade)) {
            return Optional.empty();
        }

        if (trade.isExecuted()) { // Only checks unexecuted orders
            return Optional.empty();
        }

        LocalDateTime referenceTime = trade.getTimestamp();
        TradeRecord record = new TradeRecord(trade.getTradeId(), referenceTime, trade.getQuantity());

        // Save to records
        String traderId = trade.getTraderId();
        recentTrades.putIfAbsent(traderId, new ArrayList<>());
        List<TradeRecord> records = recentTrades.get(traderId);
        records.add(record);

        // Remove records that are no longer in the sliding window
        records.removeIf(r ->
                Duration.between(r.timestamp, referenceTime).getSeconds() > timeWindow
        );

        // Count and check
        long count = records.stream()
                .filter(r -> r.quantity >= minQuantity)
                .count();

        if (count >= minCount) {
            Alert alert = AlertBuilder.build(
                    "SPOOFING",
                    count + " large unexecuted orders in last " + timeWindow +
                            "s from trader " + traderId + ", suspicious orders: " + records,
                    trade
            );
            return Optional.of(alert);
        }

        return Optional.empty();
    }

    /**
     * Determines if this detector supports the given trade's asset type.
     * Currently only supports crypto assets.
     * 
     * @param trade The trade to check for support
     * @return true if the asset type is "crypto", false otherwise
     */
    @Override
    public boolean supports(CanonicalTrade trade) {
        // Monitors crypto only
        return "crypto".equalsIgnoreCase(trade.getAssetType());
    }

    /**
     * Inner class representing a trade record for spoofing detection.
     * Stores the essential information needed to identify spoofing patterns.
     */
    @AllArgsConstructor
    private static class TradeRecord { // Inner class specifically for Spoofing (different from the one in FlashCrash)
        String tradeID; // Unique identifier of the trade
        LocalDateTime timestamp; // When the trade occurred
        int quantity; // Number of units in the trade

        @Override
        public String toString() {
            String timeStr = timestamp
                    .atZone(ZoneId.systemDefault())
                    .format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));

            return "TradeRecord(tradeID=" + tradeID +
                    ", timestamp=" + timeStr +
                    ", quantity=" + quantity + ")";
        }
    }
}