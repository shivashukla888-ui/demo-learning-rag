package com.github.andrewyying.finalprojectandrewyying.validation;

/**
 * Builder class that constructs the chain of trade validators.
 * Creates and links validators in the appropriate order to form a validation pipeline.
 */
public class TradeValidationChainBuilder {
    /**
     * Builds and returns a chain of trade validators.
     * The validators are linked in the following order:
     * 1. Format validation
     * 2. Amount validation
     * 3. Asset type validation
     *
     * @return The first validator in the chain (FormatValidator)
     */
    public static TradeValidator build() {
        TradeValidator formatValidator = new FormatValidator(); // Validates basic format requirements
        TradeValidator amountValidator = new AmountValidator(); // Validates trade amount constraints
        TradeValidator assetTypeValidator = new AssetTypeValidator(); // Validates asset type requirements

        // Link the validators in a chain
        formatValidator.setNext(amountValidator);
        amountValidator.setNext(assetTypeValidator);

        return formatValidator; // Return the head of the chain
    }
}

