package com.github.andrewyying.finalprojectandrewyying.alert;

import com.github.andrewyying.finalprojectandrewyying.model.Alert;
import com.github.andrewyying.finalprojectandrewyying.util.ConfigCenter;

/**
 * Utility class that determines the severity level of alerts based on their type.
 * Uses configuration settings to map alert types to appropriate severity levels.
 */
public class AlertSeverityClassifier {

    static ConfigCenter config = ConfigCenter.getInstance(); // Configuration center for accessing severity level settings

    /**
     * Classifies an alert by determining its severity level based on alert type.
     * Maps known alert types to configured severity levels, with a default for unknown types.
     *
     * @param alert The alert to classify
     * @return A string representing the severity level (e.g., "HIGH", "MEDIUM", "LOW")
     */
    public static String classify(Alert alert) {
        String type = alert.getAlertType();

        return switch (type) {
            case "WASH_TRADE" -> config.getWashTradeSeverity();
            case "FLASH_TRADE" -> config.getFlashTradeSeverity();
            case "SPOOFING" -> config.getSpoofingSeverity();
            default -> config.getDefaultSeverity();
        };
    }
}
