package com.github.andrewyying.finalprojectandrewyying.subscriber;

import com.github.andrewyying.finalprojectandrewyying.model.Alert;
import com.github.andrewyying.finalprojectandrewyying.util.ConfigCenter;
import org.springframework.stereotype.Component;

/**
 * Subscriber that sends email notifications for high severity alerts.
 * Filters alerts based on severity and sends email notifications only for
 * those with "HIGH" severity to configured recipients.
 */
@Component
public class EmailSubscriber implements AlertSubscriber {
    /**
     * Handles an alert by sending an email notification if the alert has high severity.
     * Currently simulates email sending by printing to console.
     * 
     * @param alert The alert to potentially send via email
     */
    @Override
    public void onAlert(Alert alert) {
        if (alert.getSeverity().equals("HIGH")){ // Only send emails for high severity alerts
            ConfigCenter configCenter = ConfigCenter.getInstance(); // Get configuration settings
            System.out.println("Email sent to: " + configCenter.getAlertEmailRecipient()); // Email simulation
        }
    }
}
