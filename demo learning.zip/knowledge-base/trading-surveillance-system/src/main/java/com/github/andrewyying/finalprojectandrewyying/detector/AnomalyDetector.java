package com.github.andrewyying.finalprojectandrewyying.detector;

import com.github.andrewyying.finalprojectandrewyying.model.Alert;
import com.github.andrewyying.finalprojectandrewyying.model.CanonicalTrade;
import java.util.Optional;

/**
 * Interface defining the contract for anomaly detectors.
 * Anomaly detectors analyze trade data to identify suspicious patterns
 * that may indicate market manipulation or other irregularities.
 */
public interface AnomalyDetector {
    /**
     * Analyzes a trade for anomalies or suspicious patterns.
     * 
     * @param trade The trade to analyze
     * @return An Optional containing an Alert if an anomaly is detected, or empty if no anomaly is found
     */
    Optional<Alert> detect(CanonicalTrade trade);
    
    /**
     * Determines if this detector supports analyzing the given trade.
     * Allows detectors to specialize in certain trade types or asset classes.
     * 
     * @param trade The trade to check for support
     * @return true if this detector can analyze the trade, false otherwise
     */
    boolean supports(CanonicalTrade trade);
}
