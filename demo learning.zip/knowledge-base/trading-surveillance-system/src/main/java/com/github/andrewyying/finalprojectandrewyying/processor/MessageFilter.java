package com.github.andrewyying.finalprojectandrewyying.processor;

import com.github.andrewyying.finalprojectandrewyying.model.CanonicalTrade;
import com.github.andrewyying.finalprojectandrewyying.util.ConfigCenter;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.springframework.stereotype.Component;

/**
 * Processor that filters trade messages based on trade amount.
 * Trades with amounts below the configured minimum are filtered out of the processing pipeline.
 */
@Component
public class MessageFilter implements Processor {

    private final ConfigCenter config = ConfigCenter.getInstance(); // Singleton Config Center for accessing system settings 

    /**
     * Processes an exchange by filtering trades based on their amount.
     * If a trade's amount (price * quantity) is below the configured minimum,
     * the exchange is marked to stop further processing.
     *
     * @param exchange The Camel exchange containing the trade to filter
     * @throws Exception If an error occurs during processing
     */
    @Override
    public void process(Exchange exchange) throws Exception {
        CanonicalTrade trade = exchange.getIn().getBody(CanonicalTrade.class);

        double minAmount = config.getFilterMinTradeAmount();
        double tradeAmount = trade.getPrice() * trade.getQuantity(); // price * quantity

        if (tradeAmount < minAmount) {
            System.out.println("Trade: " + trade.getTradeId() +  " is filtered out - amount too little: " + tradeAmount);
            exchange.setProperty("CamelRouteStop", true);
        }
    }
}