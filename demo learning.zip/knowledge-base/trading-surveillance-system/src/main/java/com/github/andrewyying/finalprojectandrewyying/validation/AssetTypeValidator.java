package com.github.andrewyying.finalprojectandrewyying.validation;

import com.github.andrewyying.finalprojectandrewyying.exception.InvalidTradeException;
import com.github.andrewyying.finalprojectandrewyying.model.CanonicalTrade;
import com.github.andrewyying.finalprojectandrewyying.util.ConfigCenter;
import org.springframework.stereotype.Component;

import java.util.Set;

/**
 * Validator that checks if the asset type in a trade is supported by the system.
 * Verifies that the asset type matches one of the configured supported asset types.
 */
@Component
public class AssetTypeValidator implements TradeValidator {
    private TradeValidator next; // The next validator in the chain

    @Override
    public void setNext(TradeValidator next) {
        this.next = next;
    }

    /**
     * Validates that the trade's asset type is supported by the system.
     * Checks if the asset type is in the list of supported asset types from configuration.
     * Passes the trade to the next validator if it passes this validation.
     *
     * @param trade The trade to validate
     * @throws InvalidTradeException If the asset type is not supported or if no supported types are configured
     */
    @Override
    public void handle(CanonicalTrade trade) throws InvalidTradeException {
        ConfigCenter config = ConfigCenter.getInstance(); // Get configuration settings
        Set<String> supportedAssets = config.getSupportedAssetTypes(); // Get supported asset types from config

        if (supportedAssets == null || supportedAssets.isEmpty()) {
            throw new InvalidTradeException("No supported asset types defined / found in config.");
        }

        if (supportedAssets.stream().noneMatch(type -> type.equalsIgnoreCase(trade.getAssetType()))) {
            throw new InvalidTradeException("Unsupported assetType '" + trade.getAssetType() + "'");
        }
        if (next != null) {
            next.handle(trade); // Pass to next validator if validation passes
        }
    }
}
