package com.github.andrewyying.finalprojectandrewyying.detector;

import com.github.andrewyying.finalprojectandrewyying.alert.AlertBuilder;
import com.github.andrewyying.finalprojectandrewyying.model.Alert;
import com.github.andrewyying.finalprojectandrewyying.model.CanonicalTrade;
import com.github.andrewyying.finalprojectandrewyying.util.ConfigCenter;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.*;

/**
 * Detector for identifying flash crashes in trading activity.
 * A flash crash is a rapid, significant drop in the price of an asset within a short time period.
 * This detector monitors price movements and alerts when they exceed configured thresholds.
 */
@Component
public class FlashCrashDetector implements AnomalyDetector {

    // Map of recent trades by symbol to track price movements
    private static final Map<String, List<TradeRecord>> recentTrades = new HashMap<>();

    /**
     * Detects flash crashes by analyzing price movements within a configured time window.
     * Alerts are generated when prices drop by a percentage exceeding the configured threshold.
     * 
     * @param trade The trade to analyze
     * @return An Optional containing an Alert if a flash crash is detected, or empty otherwise
     */
    @Override
    public Optional<Alert> detect(CanonicalTrade trade) {

        if (!supports(trade)) {
            return Optional.empty();
        }

        if (!trade.isExecuted()) { // Only checks executed orders
            return Optional.empty();
        }

        ConfigCenter config = ConfigCenter.getInstance();
        int timeWindow = config.getFlashCrashTimeWindow(); // Time window in seconds to analyze
        double priceDropThreshold = config.getFlashCrashPriceDropThreshold(); // Minimum percentage drop to trigger alert

        LocalDateTime referenceTime = trade.getTimestamp();
        TradeRecord record = new TradeRecord(trade.getTradeId(), referenceTime, trade.getPrice());

        String symbol = trade.getSymbol();
        List<TradeRecord> history = recentTrades.computeIfAbsent(symbol, k -> new ArrayList<>());
        history.add(record);

        // Remove trades that are no longer in the time window
        history.removeIf(r -> r.timestamp.plusSeconds(timeWindow).isBefore(referenceTime));

        // Get the highest price in the window & the drop%
        double maxPrice = history.stream().mapToDouble(r -> r.price).max().orElse(record.price);
        double drop = (maxPrice - record.price) / maxPrice;

        // Check for flash crash
        if (drop >= priceDropThreshold) {
            Alert alert = AlertBuilder.build(
                    "FLASH_CRASH",
                    String.format("Flash crash in %s: price dropped %.2f%% from %.2f to %.2f within %ds",
                            symbol,
                            drop * 100,
                            maxPrice,
                            record.price,
                            timeWindow),
                    trade
            );
            return Optional.of(alert);
        }

        return Optional.empty();
    }

    /**
     * Determines if this detector supports the given trade's asset type.
     * Checks configuration to see if flash crash detection is enabled for this asset type.
     * 
     * @param trade The trade to check for support
     * @return true if flash crash detection is supported for this asset type, false otherwise
     */
    @Override
    public boolean supports(CanonicalTrade trade) {
        ConfigCenter config = ConfigCenter.getInstance(); // Get configuration settings
        List<String> supportedAssets = config.getFlashCrashSupportedAssets(); // Get assets that support flash crash detection
        return supportedAssets.stream().anyMatch(type -> type.equalsIgnoreCase(trade.getAssetType()));
    }

    /**
     * Inner class representing a trade record for flash crash detection.
     * Stores the essential information needed to identify price movements.
     */
    @AllArgsConstructor
    private static class TradeRecord { // Inner class specifically for flash crash (different from the one in spoofing)
        String tradeID; // Unique identifier of the trade
        LocalDateTime timestamp; // When the trade occurred
        double price; // Price of the asset in the trade

        @Override
        public String toString() {
            String timeStr = timestamp
                    .atZone(ZoneId.systemDefault())
                    .format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));

            return "TradeRecord(tradeID=" + tradeID +
                    ", timestamp=" + timeStr +
                    ", price=" + price + ")";
        }
    }
}
