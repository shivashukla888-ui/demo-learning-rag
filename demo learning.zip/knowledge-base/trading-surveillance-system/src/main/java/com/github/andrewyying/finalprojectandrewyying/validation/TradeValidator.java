package com.github.andrewyying.finalprojectandrewyying.validation;

import com.github.andrewyying.finalprojectandrewyying.exception.InvalidTradeException;
import com.github.andrewyying.finalprojectandrewyying.model.CanonicalTrade;

/**
 * Interface defining the contract for trade validators.
 * Implements the Chain of Responsibility pattern for validating trades
 * through a series of validators.
 */
public interface TradeValidator {
    /**
     * Sets the next validator in the chain.
     * 
     * @param next The next validator to process the trade if this one passes
     */
    void setNext(TradeValidator next);
    
    /**
     * Validates the trade and passes it to the next validator if valid.
     * 
     * @param trade The trade to validate
     * @throws InvalidTradeException If the trade fails validation
     */
    void handle(CanonicalTrade trade) throws InvalidTradeException;
}