package com.github.andrewyying.finalprojectandrewyying;

import com.github.andrewyying.finalprojectandrewyying.exception.InvalidTradeException;
import com.github.andrewyying.finalprojectandrewyying.processor.*;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Apache Camel route definition for processing trade messages.
 * This route consumes messages from an ActiveMQ queue, processes them through
 * a series of processors for validation, filtering, and detection.
 */
@Component
public class SimpleTradeConsumerRoute extends RouteBuilder {

    private final UnifiedDetectionProcessor detectionProcessor;
    private final BatchTradeSplitter batchTradeSplitter;
    private final MessageFilter messageFilter;
    private final MessageValidator messageValidator;

    /**
     * Constructs a new SimpleTradeConsumerRoute with the required processors.
     *
     * @param detectionProcessor Processor for pattern detection in trades
     * @param batchTradeSplitter Processor for splitting batch trades
     * @param messageFilter Processor for filtering messages
     * @param messageValidator Processor for validating messages
     */
    @Autowired
    public SimpleTradeConsumerRoute(UnifiedDetectionProcessor detectionProcessor, BatchTradeSplitter batchTradeSplitter, MessageFilter messageFilter, MessageValidator messageValidator) {
        this.detectionProcessor = detectionProcessor;
        this.batchTradeSplitter = batchTradeSplitter;
        this.messageFilter = messageFilter;
        this.messageValidator = messageValidator;
    }

    /**
     * Configures the Camel route for trade message processing.
     * Defines error handling and the sequence of processors to apply to each message.
     */
    @Override
    public void configure() {
        // Error handling for invalid trades
        onException(InvalidTradeException.class)
                .handled(true)
                .process(new DeadLetterHandler());

        // Main processing route
        from("activemq:queue:TRADE_INPUT")
                .routeId("basic-trade-consumer")
                .process(batchTradeSplitter)  // Split batch trades into individual trades
                .split(body())                // Process each trade individually
                .process(messageValidator)    // Validate trade message format and content
                .process(messageFilter)       // Filter messages based on criteria
                .filter(exchangeProperty("CamelRouteStop").isNotEqualTo(true))
                    .process(detectionProcessor)  // Detect patterns in valid trades
                    .log("Finished processing trade: ${body}");
    }
}