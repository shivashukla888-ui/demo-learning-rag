package com.github.andrewyying.finalprojectandrewyying.processor;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.github.andrewyying.finalprojectandrewyying.exception.InvalidTradeException;
import com.github.andrewyying.finalprojectandrewyying.model.CanonicalTrade;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Processor that splits batch trade messages into individual trade objects.
 * Handles both single trade messages (JSON objects) and batch trade messages (JSON arrays).
 */
@Component
public class BatchTradeSplitter implements Processor {
    private final ObjectMapper objectMapper; // JSON object mapper for deserializing trade data

    /**
     * Constructs a new BatchTradeSplitter with a configured ObjectMapper.
     * Registers JavaTimeModule to handle date/time serialization and deserialization.
     */
    public BatchTradeSplitter() {
        objectMapper = new ObjectMapper();
        objectMapper.registerModule(new JavaTimeModule());
    }

    /**
     * Processes an exchange by deserializing the message body into trade objects.
     * If the message is a single JSON object, it's converted to a single-element list.
     * If the message is a JSON array, it's converted to a list of trade objects.
     *
     * @param exchange The Camel exchange containing the message to process
     * @throws Exception If an error occurs during processing
     * @throws InvalidTradeException If the timestamp format is invalid
     */
    @Override
    public void process(Exchange exchange) throws Exception {
        String body = exchange.getIn().getBody(String.class).trim();

        try {
            if (body.startsWith("{")) {
                // Single trade message
                CanonicalTrade trade = objectMapper.readValue(body, CanonicalTrade.class);
                exchange.getIn().setBody(List.of(trade));
            } else {
                // Batch trade message
                List<CanonicalTrade> trades = objectMapper.readValue(body, new TypeReference<>() {});
                exchange.getIn().setBody(trades);
            }
        } catch (com.fasterxml.jackson.databind.exc.InvalidFormatException e) {
            // Only care about LocalDateTime parsing failure
            throw new InvalidTradeException("Invalid 'timestamp' format. Expected ISO-8601 like yyyy-MM-dd'T'HH:mm:ss.");
        }
    }
}
