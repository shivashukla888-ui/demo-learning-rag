package com.github.andrewyying.finalprojectandrewyying.processor;

import com.github.andrewyying.finalprojectandrewyying.exception.InvalidTradeException;
import com.github.andrewyying.finalprojectandrewyying.model.CanonicalTrade;
import com.github.andrewyying.finalprojectandrewyying.validation.TradeValidator;
import com.github.andrewyying.finalprojectandrewyying.validation.TradeValidationChainBuilder;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.springframework.stereotype.Component;

/**
 * Processor that validates trade messages using a chain of validators.
 * Applies validation rules to ensure trade data meets required criteria.
 */
@Component
public class MessageValidator implements Processor {
    private final TradeValidator chain = TradeValidationChainBuilder.build(); // Chain of validators to apply to each trade message

    /**
     * Processes an exchange by validating the trade message.
     * Applies a chain of validation rules to the trade object.
     *
     * @param exchange The Camel exchange containing the trade to validate
     * @throws InvalidTradeException If the trade fails validation
     */
    @Override
    public void process(Exchange exchange) throws InvalidTradeException {
        CanonicalTrade trade = exchange.getIn().getBody(CanonicalTrade.class);
        chain.handle(trade);
    }
}
